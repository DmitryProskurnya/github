package com.example.a9_31;
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.snackbar.Snackbar;
public class MainActivity extends AppCompatActivity {
    TextView tvFirstNumber, tvSecondNumber, tvAnswer;
    EditText edFirstNumber, edSecondNumber;
    Button btnMinus, btnPlus, btnDivide, btnTimes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvFirstNumber = (TextView)findViewById(R.id.tvFirstNumber);
        edFirstNumber = (EditText)findViewById(R.id.edFirstNumber);
        tvSecondNumber = (TextView)findViewById(R.id.tvSecondNumber);
        edSecondNumber = (EditText)findViewById(R.id.edSecondNumber);
        btnMinus = (Button)findViewById(R.id.btnMinus);
        btnPlus = (Button)findViewById(R.id.btnPlus);
        btnDivide = (Button)findViewById(R.id.btnDivide);
        btnTimes = (Button)findViewById(R.id.btnTimes);
        tvAnswer = (TextView)findViewById(R.id.tvAnswer);
    }
    public void ClickButton(View view) {
//        String message = tvFirstNumber.getText()+", "+ edFirstNumber.getText().toString();
//        tvFirstNumber.setTextColor(Color.BLUE);
//        tvFirstNumber.setText(message);
//        Toast.makeText(this,"Toast",Toast.LENGTH_SHORT).show();
//        Snackbar.make(view, "Snackbar", Snackbar.LENGTH_LONG).show();
        int number1 = Integer.parseInt(edFirstNumber.getText().toString());
        int number2 = Integer.parseInt(edSecondNumber.getText().toString());
        int answer = 0;
        if(number1 == 0 || number2 == 0){
            Snackbar.make(view, "Введите все поля!", Snackbar.LENGTH_LONG).show();
            return;
        }
        if(view.getId()==R.id.btnMinus){
            answer = number1 - number2;
            tvAnswer.setText(String.valueOf(answer));
        }
        if(view.getId()==R.id.btnPlus){
            answer = number1 + number2;
            tvAnswer.setText(String.valueOf(answer));
        }
        if(view.getId()==R.id.btnDivide){
            answer = number1 / number2;
            tvAnswer.setText(String.valueOf(answer));
        }
        if(view.getId()==R.id.btnTimes){
            answer = number1 * number2;
            tvAnswer.setText(String.valueOf(answer));
        }
    }

}