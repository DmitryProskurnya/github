package com.example.anketaapp;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
public class AnketaActivity extends AppCompatActivity {
    static ArrayList<User> profiles = new ArrayList<>();
    static ArrayList<String> listFam = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anketa);
        ListView userList = findViewById(R.id.userList);
        UserList();
        CopyList();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listFam);
        userList.setAdapter(adapter);
        userList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), UserActivity.class);
                intent.putExtra("ggg",position);
                startActivity(intent);
                if(position==0){

                }
            }
        });
        userList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View childView,
                                       int position, long id)
            {
            }
            public void onNothingSelected(AdapterView parentView) { }
        });
        /*userList.setOnCreateContextMenuListener(new AdapterView.setOnCreateContextMenuListener() {
            @Override
            public boolean onContextItemSelected(@NonNull MenuItem item){
                AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                int position = info.position;
                int id = item.getItemId();
                if(id == R.id.optionDelete){
                    profiles.remove(position);
                    listFam.remove(position);
                    adapter.notifyDataSetChanged();
                    return true;
                }
                return super.onContextItemSelected(item);
            }
        });*/
    }
    void CopyList(){
        for(int i = 0; i < profiles.size(); i++){
            listFam.add(profiles.get(i).surname);
        }
    }
    void UserList(){
        profiles.add(new User("Пётр", "Петров", "89493940284", "ya.ru", "60, 30"));
        profiles.add(new User("Сидр", "Сидоров", "89346346263", "ya.ru", "60, 30"));
        profiles.add(new User("Кузьма", "Кузнецов", "87498388290", "ya.ru", "60, 30"));
        profiles.add(new User("Василий", "Васильев", "85776463682", "ya.ru", "60, 30"));
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo){
        getMenuInflater().inflate(R.menu.context, menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int id = item.getItemId();
        if(id == R.id.main_one){
            Intent intent = new Intent(getApplicationContext(), UserActivity.class);
            startActivity(intent);
        }
        if(id == R.id.main_two){
            Toast.makeText(this, "Two", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}