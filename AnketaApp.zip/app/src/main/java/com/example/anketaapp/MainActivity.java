package com.example.anketaapp;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {
    public static User user = new User();
    public static Boolean filled = false;
    Button btnAdd;
    Button btnSee;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAdd = findViewById(R.id.btnAdd);
        btnSee = findViewById(R.id.btnSee);
    }
    public void btnClick (View v){
        Intent intent = new Intent(this, UserActivity.class);
        startActivity(intent);
    }
    @Override
    protected void onResume() {
        super.onResume();
        if(!filled) {
            btnAdd.setVisibility(View.VISIBLE);
            btnSee.setVisibility(View.INVISIBLE);
        }
        else {
            btnAdd.setVisibility(View.INVISIBLE);
            btnSee.setVisibility(View.VISIBLE);
        }
    }
}