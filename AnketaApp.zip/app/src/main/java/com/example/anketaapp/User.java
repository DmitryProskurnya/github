package com.example.anketaapp;
import java.io.Serializable;
public class User implements Serializable {
    public String name;
    public String surname;
    public String phone;
    public String site;
    public String address;
    public User() {
        this.name = "";
        this.surname = "";
        this.phone = "";
        this.site = "";
        this.address = "";
    }
    public User(String name, String surname, String phone, String site, String address) {
        this.name = name;
        this.surname = surname;
        this.phone = phone;
        this.site = site;
        this.address = address;
    }
    public String getName() {
        return this.name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getSurname() {
        return this.surname;
    }
    public void setSurname(String surname) {
        this.surname = surname;
    }
    public String getPhone() {
        return this.phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getSite() {
        return this.site;
    }
    public void setSite(String site) {
        this.site = site;
    }
    public String getAddress() {
        return this.address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
}