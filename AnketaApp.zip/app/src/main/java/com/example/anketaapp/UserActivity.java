package com.example.anketaapp;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
public class UserActivity extends AppCompatActivity {
    EditText edName, edSurname, edPhone, edSite, edAddress;
    ImageButton btnPhone, btnSite, btnAddress;
    Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        edName = findViewById(R.id.edName);
        edSurname = findViewById(R.id.edSurname);
        edPhone = findViewById(R.id.edPhone);
        edSite = findViewById(R.id.edSite);
        edAddress = findViewById(R.id.edAddress);
        btnPhone = findViewById(R.id.btnPhone);
        btnSite = findViewById(R.id.btnSite);
        btnAddress = findViewById(R.id.btnAddress);
        btnSave = findViewById(R.id.btnSave);
        edName.setText(MainActivity.user.name);
        edSurname.setText(MainActivity.user.surname);
        edPhone.setText(MainActivity.user.phone);
        edSite.setText(MainActivity.user.site);
        edAddress.setText(MainActivity.user.address);
        if (!MainActivity.filled) {
            btnPhone.setVisibility(View.INVISIBLE);
            btnSite.setVisibility(View.INVISIBLE);
            btnAddress.setVisibility(View.INVISIBLE);
        }
    }

    public void btnClick(View view) {
        if (view.getId() == R.id.btnPhone) {
            try {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + edPhone.getText().toString()));
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "ОШИБКА! Не удалось открыть контакты!", Toast.LENGTH_LONG).show();
            }
        }
        if (view.getId() == R.id.btnSite) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(edSite.getText().toString()));
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "ОШИБКА! Не удалось открыть браузер!", Toast.LENGTH_LONG).show();
            }
        }
        if (view.getId() == R.id.btnAddress) {
            try {
                String strUri = "http://maps.google.com/maps?q=loc:" + edAddress.getText().toString();
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(strUri));
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "ОШИБКА! Не удалось открыть карту!", Toast.LENGTH_LONG).show();
            }
        }
        if (view.getId() == R.id.btnSave) {
            if (edName.getText().toString().trim().length() == 0 || edSurname.getText().toString().trim().length() == 0 || edPhone.getText().toString().trim().length() == 0 || edSite.getText().toString().trim().length() == 0 || edAddress.getText().toString().trim().length() == 0) {
                Toast.makeText(this, "Данные не полностью заполнены!", Toast.LENGTH_LONG).show();
            } else {
                MainActivity.filled = true;
                MainActivity.user.name = edName.getText().toString();
                MainActivity.user.surname = edSurname.getText().toString();
                MainActivity.user.phone = edPhone.getText().toString();
                MainActivity.user.site = edSite.getText().toString();
                MainActivity.user.address = edAddress.getText().toString();
                finish();
            }
        }
    }
}