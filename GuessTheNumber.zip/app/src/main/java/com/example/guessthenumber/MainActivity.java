package com.example.guessthenumber;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
public class MainActivity extends AppCompatActivity {
    EditText edText;
    Button btnOk;
    TextView tvResult;
    ImageView smile;
    Button btnAgain;
    int number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edText = findViewById(R.id.edText);
        btnOk = findViewById(R.id.btnAgain);
        tvResult = findViewById(R.id.tvResult);
        smile = findViewById(R.id.smile);
        btnAgain = findViewById(R.id.btnAgain);
        startGame();
    }
    private int RandomNumber(){
        Random objGenerator = new Random();
        int randomNumber = 0;
        randomNumber = objGenerator.nextInt(10);
        return randomNumber;
    }
    public void Btn_Click(View v){
        if(v.getId(R.id.btnAgain)) {
            startGame();
        }
        else if(v.getId(R.id.btnOK)) {
            int numberUser = -1;
            try {
                numberUser = Integer.parseInt(edText.getText().toString());
            } catch (Exception ex) {
                tvResult.setText("Введите число!");
                return;
            }
            if (number == numberUser) {
                tvResult.setTextColor(Color.GREEN);
                tvResult.setText("Вы победили!");
                btnAgain.setVisibility(View.VISIBLE);
                smile.setVisibility(View.VISIBLE);
            } else {
                if (number > numberUser) {
                    tvResult.setTextColor(Color.RED);
                    tvResult.setText("Ваше число меньше нужного!");
                } else {
                    tvResult.setTextColor(Color.BLUE);
                    tvResult.setText("Ваше число больше нужного!");
                }
            }
        }
    }
    private void startGame(){
        tvResult.setText("");
        edText.setText("");
        btnAgain.setVisibility(View.INVISIBLE);
        smile.setVisibility(View.INVISIBLE);
        number = RandomNumber();
    }
}