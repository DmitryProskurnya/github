package com.alexkarav.mobileexam;

import android.app.Application;

import androidx.room.Room;

import com.alexkarav.mobileexam.data.TaskDatabase;

public class TaskApplication extends Application {
    private static TaskApplication INSTANCE;
    private TaskDatabase database;

    @Override
    public void onCreate() {
        super.onCreate();
        INSTANCE = this;
        database = Room.databaseBuilder(this, TaskDatabase.class, "task_db")
                .allowMainThreadQueries()
                .build();
    }

    public static TaskApplication getINSTANCE() {
        return INSTANCE;
    }

    public TaskDatabase getDatabase() {
        return database;
    }
}
