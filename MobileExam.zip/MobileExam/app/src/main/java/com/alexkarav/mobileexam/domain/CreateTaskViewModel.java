package com.alexkarav.mobileexam.domain;

import androidx.lifecycle.ViewModel;

import com.alexkarav.mobileexam.TaskApplication;
import com.alexkarav.mobileexam.data.TaskDao;
import com.alexkarav.mobileexam.data.TaskModel;

public class CreateTaskViewModel extends ViewModel {
    private TaskDao dao = TaskApplication
            .getINSTANCE()
            .getDatabase()
            .getTaskDao();

    public void saveNewTask(String taskName, String taskText) {
        TaskModel newTask = new TaskModel();
        newTask.setTaskName(taskName);
        newTask.setTaskText(taskText);
        dao.insertNewTasks(newTask);
    }


}
