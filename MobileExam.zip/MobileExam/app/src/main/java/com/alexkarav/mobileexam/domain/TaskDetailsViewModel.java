package com.alexkarav.mobileexam.domain;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.alexkarav.mobileexam.TaskApplication;
import com.alexkarav.mobileexam.data.TaskDao;
import com.alexkarav.mobileexam.data.TaskModel;

public class TaskDetailsViewModel extends ViewModel {
    private TaskDao dao = TaskApplication
            .getINSTANCE()
            .getDatabase()
            .getTaskDao();

    private MutableLiveData<TaskModel> _task = new MutableLiveData<>(null);
    public LiveData<TaskModel> task() {
        return _task;
    }

    public void loadTaskInfo(int taskId) {
        _task.setValue(dao.getTaskById(taskId));
    }

}
