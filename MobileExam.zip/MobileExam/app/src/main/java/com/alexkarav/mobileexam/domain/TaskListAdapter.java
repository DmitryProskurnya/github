package com.alexkarav.mobileexam.domain;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alexkarav.mobileexam.data.TaskModel;
import com.alexkarav.mobileexam.databinding.TaskListItemBinding;

import java.util.ArrayList;

public class TaskListAdapter extends RecyclerView.Adapter<TaskListAdapter.ViewHolder> {
    private ArrayList<TaskModel> tasks;

    public interface onItemClick {
        void onTaskListItemClick(int position, TaskModel task);
    }

    private onItemClick clickListener;

    public TaskListAdapter(ArrayList<TaskModel> tasks, TaskListAdapter.onItemClick onItemClick) {
        this.tasks = tasks;
        clickListener = onItemClick;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(TaskListItemBinding.inflate(LayoutInflater.from(parent.getContext())));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.binding.taskName.setText(tasks.get(position).getTaskName());
        holder.binding.getRoot().setOnClickListener(view -> {
            clickListener.onTaskListItemClick(position, tasks.get(position));
        });
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    public void updateData(ArrayList<TaskModel> newTasks) {
        this.tasks = newTasks;
        notifyDataSetChanged();
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        private final TaskListItemBinding binding;
        public ViewHolder(TaskListItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

}
