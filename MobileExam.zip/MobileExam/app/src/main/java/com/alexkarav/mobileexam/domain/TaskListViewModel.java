package com.alexkarav.mobileexam.domain;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.alexkarav.mobileexam.TaskApplication;
import com.alexkarav.mobileexam.data.TaskDao;
import com.alexkarav.mobileexam.data.TaskModel;

import java.util.ArrayList;
import java.util.List;

public class TaskListViewModel extends ViewModel {
    private TaskDao dao = TaskApplication
            .getINSTANCE()
            .getDatabase()
            .getTaskDao();

    public LiveData<List<TaskModel>> tasks() {
        return dao.getAllTasks();
    }



}
