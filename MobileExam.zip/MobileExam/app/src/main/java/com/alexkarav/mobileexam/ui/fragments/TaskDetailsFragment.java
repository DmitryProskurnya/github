package com.alexkarav.mobileexam.ui.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alexkarav.mobileexam.databinding.FragmentTaskDetailsBinding;
import com.alexkarav.mobileexam.domain.TaskDetailsViewModel;


public class TaskDetailsFragment extends Fragment {
    private FragmentTaskDetailsBinding binding;
    private TaskDetailsViewModel viewModel;

    public TaskDetailsFragment() {}

    public static TaskDetailsFragment newInstance() {
        return new TaskDetailsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentTaskDetailsBinding.inflate(LayoutInflater.from(requireContext()));
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(TaskDetailsViewModel.class);
        int taskId = TaskDetailsFragmentArgs.fromBundle(getArguments()).getTaskId();
        viewModel.loadTaskInfo(taskId);
        viewModel.task().observe(getViewLifecycleOwner(), task -> {
            if(task != null) {
                binding.taskName.setText(task.getTaskName());
                binding.taskText.setText(task.getTaskText());
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        viewModel = null;
    }
}