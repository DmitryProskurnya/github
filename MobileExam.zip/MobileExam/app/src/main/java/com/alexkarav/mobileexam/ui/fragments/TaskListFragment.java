package com.alexkarav.mobileexam.ui.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alexkarav.mobileexam.R;
import com.alexkarav.mobileexam.data.TaskModel;
import com.alexkarav.mobileexam.databinding.FragmentTaskListBinding;
import com.alexkarav.mobileexam.domain.TaskListAdapter;
import com.alexkarav.mobileexam.domain.TaskListViewModel;

import java.util.ArrayList;


public class TaskListFragment extends Fragment {
    private FragmentTaskListBinding binding;
    private TaskListViewModel viewModel;

    public TaskListFragment() {}

    public static TaskListFragment newInstance() {
        return new TaskListFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentTaskListBinding.inflate(LayoutInflater.from(requireContext()), container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(TaskListViewModel.class);
        TaskListAdapter adapter = new TaskListAdapter(new ArrayList<>(), (position, task) ->
            Navigation.findNavController(binding.getRoot()).navigate(TaskListFragmentDirections.actionTaskListFragmentToTaskDetailsFragment(task.getTaskId())));
        viewModel.tasks().observe(getViewLifecycleOwner(), tasks -> {
            Log.d("TASKS", "Received new tasks");
            adapter.updateData((ArrayList<TaskModel>) tasks);
        });
        binding.addNewTaskButton.setOnClickListener(v -> {
            Navigation.findNavController(binding.getRoot()).navigate(R.id.action_taskListFragment_to_createTaskFragment);
        });
        binding.taskList.setAdapter(adapter);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        viewModel = null;
    }
}