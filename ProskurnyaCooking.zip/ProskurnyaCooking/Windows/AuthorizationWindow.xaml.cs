﻿using ProskurnyaCooking.Classes;
using ProskurnyaCooking.Models;
using ProskurnyaCooking.Windows;
using System.Windows;
namespace ProskurnyaCooking
{
    /// <summary>
    /// Логика взаимодействия для AuthorizationWindow.xaml
    /// </summary>
    public partial class AuthorizationWindow : Window
    {
        UserFromDb userFromDb = new UserFromDb();
        public static User currentUser { get; set; } = null;
        public AuthorizationWindow()
        {
            InitializeComponent();
        }
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (!(tbLogin.Text != "" && tbPassword.Text != ""))
            {
                MessageBox.Show("Введите данные!");
                return;
            }
            else
            {
                currentUser = userFromDb.GetUser(tbLogin.Text, tbPassword.Text);
                if (currentUser != null)
                {
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Hide();
                }
                else
                {
                    CaptchaWindow captchaWindow = new CaptchaWindow();
                    captchaWindow.Show();
                    this.Hide();
                    return;
                }
            }
        }
        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWindow registrationWindow = new RegistrationWindow();
            registrationWindow.Show();
            this.Hide();
        }
    }
}