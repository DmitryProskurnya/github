﻿using System.Windows;
using ProskurnyaCooking.Models;
namespace ProskurnyaCooking
{
    /// <summary>
    /// Логика взаимодействия для RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        UserFromDb userFromDb = new UserFromDb();
        public RegistrationWindow()
        {
            InitializeComponent();
        }
        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            if (tbName.Text == "" || tbSurname.Text == "" || tbLogin.Text == "" || tbPassword.Text == "" || tbConfirm.Text == "")
            {
                MessageBox.Show("Необходимо заполнить все поля!");
                return;
            }
            bool rez = userFromDb.CheckPassword(tbPassword.Text, tbConfirm.Text);
            if (!rez)
            {
                return;
            }
            else
            {
                if (userFromDb.CheckUser(tbLogin.Text))
                {
                    userFromDb.UserAdd(tbLogin.Text, tbPassword.Text, tbName.Text, tbSurname.Text);
                }
                else
                {
                    return;
                }
            }
        }
    }
}