﻿namespace ProskurnyaDmitrySchool.Classes
{
    public class Class
    {
        public int ClassNumber { get; set; }
        public string Specialization { get; set; }
        public int NumberOfStudents { get; set; }
        public Class(int classNumber, string specialization, int numberOfStudents)
        {
            ClassNumber = classNumber;
            Specialization = specialization;
            NumberOfStudents = numberOfStudents;
        }
    }
}