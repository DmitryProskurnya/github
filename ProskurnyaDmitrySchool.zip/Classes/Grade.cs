﻿using System;
namespace ProskurnyaDmitrySchool.Classes
{
    public class Grade
    {
        public int StudentNumber { get; set; }
        public int SubjectCode { get; set; }
        public int Grades { get; set; }
        public DateTime AssessmentDate { get; set; }
        public string PresenceAbsence { get; set; }
        public Grade(int studentNumber, int subjectCode, int grades, DateTime assessmentDate, string presenceAbsence)
        {
            StudentNumber = studentNumber;
            SubjectCode = subjectCode;
            Grades = grades;
            AssessmentDate = assessmentDate;
            PresenceAbsence = presenceAbsence;
        }
    }
}