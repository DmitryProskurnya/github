﻿namespace ProskurnyaDmitrySchool.Classes
{
    public class Student
    {
        //Поля соответствуют таблице БД ученики
        public int StudentNumber { get; set; }
        public string StudentName { get; set; }
        public string Specialization { get; set; }
        public string SubjectName { get; set; }
        public int Grade { get; set; }
        public string TeacherName { get; set; }
        public Student(int studentNumber, string studentName, string specialization, string subjectName, int grade, string teacherName)
        {
            StudentNumber = studentNumber;
            StudentName = studentName;
            Specialization = specialization;
            SubjectName = subjectName;
            Grade = grade;
            TeacherName = teacherName;
        }
    }
}