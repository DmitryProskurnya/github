﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ProskurnyaDmitrySchool.Classes
{
    public class Student
    {
        public int StudentNumber { get; set; }
        public string StudentName { get; set; }
        public string Specialization { get; set; }
        public string SubjectName { get; set; }
        public int Grade { get; set; }
        public Student(int studentNumber, string studentName, string specialization, string subjectName, int grade)
        {
            StudentNumber = studentNumber;
            StudentName = studentName;
            Specialization = specialization;
            SubjectName = subjectName;
            Grade = grade;
        }
    }
}