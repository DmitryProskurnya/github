﻿using System;
namespace ProskurnyaDmitrySchool.Classes
{
    public class StudentAdd
    {
        public int StudentNumber { get; set; }
        public int ClassNumber { get; set; }
        public string StudentName { get; set; }
        public DateTime StudentDateOfBirth { get; set; }
        public string StudentHomeAddress { get; set; }
        public string StudentPhoneNumber { get; set; }
        public int OrderNumber { get; set; }
        public DateTime OrderDate { get; set; }
        public StudentAdd(int studentNumber, int classNumber, string studentName, DateTime studentDateOfBirth, string studentHomeAddress, string studentPhoneNumber, int orderNumber, DateTime orderDate)
        {
            StudentNumber = studentNumber;
            ClassNumber = classNumber;
            StudentName = studentName;
            StudentDateOfBirth = studentDateOfBirth;
            StudentHomeAddress = studentHomeAddress;
            StudentPhoneNumber = studentPhoneNumber;
            OrderNumber = orderNumber;
            OrderDate = orderDate;
        }
    }
}