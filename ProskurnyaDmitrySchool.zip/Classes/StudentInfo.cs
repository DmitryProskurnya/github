﻿using System;
namespace ProskurnyaDmitrySchool.Classes
{
    public class StudentInfo
    {
        public int StudentNumber { get; set; }
        public string Specialization { get; set; }
        public string StudentName { get; set; }
        public DateTime StudentDateOfBirth { get; set; }
        public string StudentHomeAddress { get; set; }
        public string StudentPhoneNumber { get; set; }
        public int OrderNumber { get; set; }
        public DateTime OrderDate { get; set; }
        public StudentInfo(int studentNumber, string specialization, string studentName, DateTime studentDateOfBirth, string studentHomeAddress, string studentPhoneNumber, int orderNumber, DateTime orderDate)
        {
            StudentNumber = studentNumber;
            Specialization = specialization;
            StudentName = studentName;
            StudentDateOfBirth = studentDateOfBirth;
            StudentHomeAddress = studentHomeAddress;
            StudentPhoneNumber = studentPhoneNumber;
            OrderNumber = orderNumber;
            OrderDate = orderDate;
        }
    }
}