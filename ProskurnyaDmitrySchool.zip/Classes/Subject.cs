﻿namespace ProskurnyaDmitrySchool.Classes
{
    public class Subject
    {
        public int SubjectCode { get; set; }
        public string SubjectName { get; set; }
        public Subject(int subjectCode, string subjectName)
        {
            SubjectCode = subjectCode;
            SubjectName = subjectName;
        }
    }
}