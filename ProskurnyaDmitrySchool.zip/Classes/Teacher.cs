﻿using System;
namespace ProskurnyaDmitrySchool.Classes
{
    public class Teacher
    {
        public int TeacherPersonnelNumber { get; set; }
        public int RoleId { get; set; }
        public string TeacherLogin { get; set; }
        public string TeacherPassword { get; set; }
        public string TeacherName { get; set; }
        public DateTime TeacherDateOfBirth { get; set; }
        public string TeacherHomeAddress { get; set; }
        public string TeacherPhoneNumber { get; set; }
        public string TeacherEmail { get; set; }
        public string TeacherPassportSeries { get; set; }
        public string TeacherPassportId { get; set; }
        public string PassportIssuedBy { get; set; }
        public DateTime PassportDateOfIssue { get; set; }
        public Teacher(int teacherPersonnelNumber, int roleId, string teacherLogin, string teacherPassword, string teacherName, DateTime teacherDateOfBirth, string teacherHomeAddress, string teacherPhoneNumber, string teacherEmail, string teacherPassportSeries, string teacherPassportId, string passportIssuedBy, DateTime passportDateOfIssue)
        {
            TeacherPersonnelNumber = teacherPersonnelNumber;
            RoleId = roleId;
            TeacherLogin = teacherLogin;
            TeacherPassword = teacherPassword;
            TeacherName = teacherName;
            TeacherDateOfBirth = teacherDateOfBirth;
            TeacherHomeAddress = teacherHomeAddress;
            TeacherPhoneNumber = teacherPhoneNumber;
            TeacherEmail = teacherEmail;
            TeacherPassportSeries = teacherPassportSeries;
            TeacherPassportId = teacherPassportId;
            PassportIssuedBy = passportIssuedBy;
            PassportDateOfIssue = passportDateOfIssue;
        }
    }
}