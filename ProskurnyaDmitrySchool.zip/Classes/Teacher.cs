﻿using System;
namespace ProskurnyaDmitrySchool.Classes
{
    public class Teacher
    {
        public int TeacherPersonnelNumber { get; set; }
        public string TeacherName { get; set; }
        public DateTime TeacherDateOfBirth { get; set; }
        public string TeacherHomeAddress { get; set; }
        public string TeacherPhoneNumber { get; set; }
        public int RoleId { get; set; }
        public string TeacherLogin { get; set; }
        public string TeacherPassword { get; set; }
        public Teacher(int teacherPersonnelNumber, string teacherName, DateTime teacherDateOfBirth, string teacherHomeAddress, string teacherPhoneNumber, int roleId, string teacherLogin, string teacherPassword)
        {
            TeacherPersonnelNumber = teacherPersonnelNumber;
            TeacherName = teacherName;
            TeacherDateOfBirth = teacherDateOfBirth;
            TeacherHomeAddress = teacherHomeAddress;
            TeacherPhoneNumber = teacherPhoneNumber;
            RoleId = roleId;
            TeacherLogin = teacherLogin;
            TeacherPassword = teacherPassword;
        }
    }
}