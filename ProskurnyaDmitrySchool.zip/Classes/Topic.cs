﻿namespace ProskurnyaDmitrySchool.Classes
{
    public class Topic
    {
        public int TopicName { get; set; }
        public string SubjectName { get; set; }
        public int HoursToStudy { get; set; }
        public string Type { get; set; }
        public Topic(int topicName, string subjectName, int hoursToStudy, string type)
        {
            TopicName = topicName;
            SubjectName = subjectName;
            HoursToStudy = hoursToStudy;
            Type = type;
        }
    }
}