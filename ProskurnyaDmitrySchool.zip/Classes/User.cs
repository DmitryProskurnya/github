﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
namespace ProskurnyaDmitrySchool.Classes
{
    public class User
    {
        public int UserId { get; set; }
        public string UserFirstName { get; set; }
        public string UserLastName { get; set; }
        public string UserPatronymic { get; set; }
        public DateTime UserDateOfBirth { get; set; }
        public string UserLogin { get; set; }
        public string UserPassword { get; set; }
        public string UserPhoneNumber { get; set; }
        public string UserHomeAddress { get; set; }
        public int RoleId { get; set; }
        public User(int userId, string userFirstName, string userLastName, string userPatronymic, DateTime userDateOfBirth, string userLogin, string userPassword, string userPhoneNumber, string userHomeAddress, int roleId)
        {
            UserId = userId;
            UserFirstName = userFirstName;
            UserLastName = userLastName;
            UserPatronymic = userPatronymic;
            UserDateOfBirth = userDateOfBirth;
            UserLogin = userPassword;
            UserPhoneNumber = userPhoneNumber;
            UserHomeAddress = userHomeAddress;
            RoleId = roleId;
        }
    }
}