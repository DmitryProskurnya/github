﻿using System;
using System.Security.Cryptography;
using System.Text;
namespace ProskurnyaDmitrySchool.Classes
{
    class Verification
    {
        //Хэширует входную строку и возвращает хеш в виде шестнадцатеричной строки из 128 символов
        public static string GetSHA512Hash(string input)
        {
            //Создаю новый экземпляр объекта MD5CryptoServiceProvider
            SHA512CryptoServiceProvider SHA512Hasher = new SHA512CryptoServiceProvider();
            //Преобразую входную строку в байтовый массив и вычисляю хеш
            byte[] data = SHA512Hasher.ComputeHash(Encoding.Default.GetBytes(input));
            //Создаю новый Stringbuilder для сбора байтов и создания строки
            StringBuilder sBuilder = new StringBuilder();
            //Перебираю каждый байт хэшированных данных и форматирую каждый как шестнадцатеричную строку
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }
            //Возвращаю шестнадцатеричную строку
            return sBuilder.ToString();
        }
        //Проверяет хэш (из базы данных) на соответствие строке (из поля ввода)
        public static bool VerifySHA512Hash(string input, string hash)
        {
            //Хэширую ввод
            string hashOfInput = GetSHA512Hash(input);
            //Создаю StringComparer для сравнения хэшей
            StringComparer comparer = StringComparer.OrdinalIgnoreCase;
            //Сравниваю два хэша
            if (0 == comparer.Compare(hashOfInput, hash))
            {
                return true;//Хэши равны
            }
            else
            {
                return false;//Не равны
            }
        }
    }
}