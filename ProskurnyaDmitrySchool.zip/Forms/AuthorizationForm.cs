﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class AuthorizationForm : Form
    {
        UsersFromDb usersFromDb = new UsersFromDb();
        public static User currentUser { get; set; } = null;
        public AuthorizationForm()
        {
            InitializeComponent();
        }
        private void btnAuhtoriz_Click(object sender, EventArgs e)
        {
            if (!(tbLogin.Text != "" && tbPassword.Text != ""))
            {
                MessageBox.Show("Введите все данные!");
            }
            else
            {
                currentUser = usersFromDb.GetUser(tbLogin.Text, tbPassword.Text);
                if (currentUser != null)
                {
                    MainForm mainForm = new MainForm();
                    mainForm.Show();
                    this.Hide();
                }
            }
        }
    }
}