﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class AuthorizationForm : Form
    {
        TeachersFromDb teachersFromDb = new TeachersFromDb();
        public static Teacher currentTeacher { get; set; } = null;
        public AuthorizationForm()
        {
            InitializeComponent();
        }
        private void btnAuhtoriz_Click(object sender, EventArgs e)
        {
            if (!(tbLogin.Text != "" && tbPassword.Text != ""))
            {
                MessageBox.Show("Введите все данные!");
                return;
            }
            else
            {
                currentTeacher = teachersFromDb.GetTeacher(tbLogin.Text, tbPassword.Text);
                if (currentTeacher != null)
                {
                    MainForm mainForm = new MainForm();
                    mainForm.Show();
                    this.Hide();
                }
                else
                {
                    CaptchaForm captchaForm = new CaptchaForm();
                    captchaForm.Show();
                    this.Hide();
                    return;
                }
            }
        }
        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegistrationForm registrationForm = new RegistrationForm();
            registrationForm.ShowDialog();
            this.Hide();
        }
    }
}