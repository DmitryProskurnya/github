﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class AuthorizationForm : Form
    {
        //Создаю экземпляр класса для использования его методов
        TeachersFromDb teachersFromDb = new TeachersFromDb();
        //Создаю объект для хранения данных о текущем авторизованном преподавателе
        //Он статический, так как может использоваться в других формах
        public static Teacher currentTeacher { get; set; } = null;
        public AuthorizationForm()
        {
            InitializeComponent();
        }
        //Обработчик нажатия на кнопку авторизации
        private void btnAuhtoriz_Click(object sender, EventArgs e)
        {
            //Если поля логина и пароля не пустые, то получаю данные о преподавателе
            if (!(tbLogin.Text != "" && tbPassword.Text != ""))
            {
                MessageBox.Show("ОШИБКА: Введите все данные!");
                return;
            }
            //Если такой преподаватель существует, то сохраняю его данные в currentTeacher и открываю главную форму
            else
            {
                currentTeacher = teachersFromDb.GetTeacher(tbLogin.Text, tbPassword.Text);
                if (currentTeacher != null)
                {
                    MainForm mainForm = new MainForm();
                    mainForm.Show();
                    this.Hide();
                }
                else
                {
                    CaptchaForm captchaForm = new CaptchaForm();
                    captchaForm.Show();
                    this.Hide();
                    return;
                }
            }
        }
        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegistrationForm registrationForm = new RegistrationForm();
            registrationForm.ShowDialog();
            this.Hide();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}