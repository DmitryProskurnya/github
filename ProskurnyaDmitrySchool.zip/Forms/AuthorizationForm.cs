﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class AuthorizationForm : Form
    {
        TeachersFromDb teachersFromDb = new TeachersFromDb();
        public static Teacher currentTeacher { get; set; } = null;
        public AuthorizationForm()
        {
            InitializeComponent();
        }
        private void btnAuhtoriz_Click(object sender, EventArgs e)
        {
            if (!(tbLogin.Text != "" && tbPassword.Text != ""))
            {
                MessageBox.Show("Введите все данные!");
            }
            else
            {
                currentTeacher = teachersFromDb.GetTeacher(tbLogin.Text, tbPassword.Text);
                if (currentTeacher != null)
                {
                    MainForm mainForm = new MainForm();
                    mainForm.Show();
                    this.Hide();
                }
            }
        }
    }
}