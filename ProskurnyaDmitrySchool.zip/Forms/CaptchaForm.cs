﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class CaptchaForm : Form
    {
        private string text;
        public CaptchaForm()
        {
            InitializeComponent();
        }
        private Bitmap CreateImage(int width, int height)
        {
            Random random = new Random();
            Bitmap bitmap = new Bitmap(width, height);
            int x = random.Next(10, width - 50);
            int y = random.Next(15, height - 15);
            Brush[] colors = { Brushes.Black, Brushes.Red, Brushes.Green, Brushes.Blue };
            Graphics g = Graphics.FromImage((Image)bitmap);
            g.Clear(Color.Gray);
            text = String.Empty;
            string albaphet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            for (int i = 0; i < 5; i++)
            {
                text += albaphet[random.Next(albaphet.Length)];
            }
            g.DrawString(text, new Font("Times New Roman", 30, FontStyle.Strikeout), colors[random.Next(colors.Length)], new PointF(x, y));
            g.DrawLine(Pens.Red, new Point(0, 0), new Point(width - 10, height - 10));
            g.DrawLine(Pens.Green, new Point(0, height - 10), new Point(width - 10, 0));
            for (int i = 0; i < width; ++i)
            {
                for (int j = 0; j < height; ++j)
                {
                    if (random.Next() % 20 == 0)
                    {
                        bitmap.SetPixel(i, j, Color.White);
                    }
                }
            }
            return bitmap;
        }
        private void CaptchaForm_Load(object sender, EventArgs e)
        {
            pbCaptcha.Image = this.CreateImage(pbCaptcha.Width, pbCaptcha.Height);
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            pbCaptcha.Image = this.CreateImage(pbCaptcha.Width, pbCaptcha.Height);
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (tbCaptcha.Text == text)
            {
                MessageBox.Show("Комбинация верна!");
                AuthorizationForm authorizationForm = new AuthorizationForm();
                authorizationForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Комбинация неверна!");
                pbCaptcha.Image = this.CreateImage(pbCaptcha.Width, pbCaptcha.Height);
            }
        }
    }
}