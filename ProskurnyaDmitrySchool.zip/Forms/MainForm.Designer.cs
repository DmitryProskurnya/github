﻿namespace ProskurnyaDmitrySchool
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsmiStudents = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiStudentsSee = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiStudentsAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiStudentsRemove = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiTopics = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSchedule = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiScheduleSee = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiScheduleEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiProfil = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiProfilEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiPasswordChange = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiProfilChange = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiExit = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiTeachers = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbStudentSearch = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbSubject = new System.Windows.Forms.ComboBox();
            this.dgvGrade = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.lblStudent = new System.Windows.Forms.Label();
            this.lbStudent = new System.Windows.Forms.ListBox();
            this.lblCount = new System.Windows.Forms.Label();
            this.tsmiGrades = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGrade)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiStudents,
            this.tsmiTopics,
            this.tsmiSchedule,
            this.tsmiProfil,
            this.tsmiTeachers,
            this.tsmiGrades});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(9, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(1200, 34);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tsmiStudents
            // 
            this.tsmiStudents.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiStudentsSee,
            this.tsmiStudentsAdd,
            this.tsmiStudentsRemove});
            this.tsmiStudents.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tsmiStudents.Name = "tsmiStudents";
            this.tsmiStudents.Size = new System.Drawing.Size(102, 28);
            this.tsmiStudents.Text = "Ученики";
            // 
            // tsmiStudentsSee
            // 
            this.tsmiStudentsSee.Name = "tsmiStudentsSee";
            this.tsmiStudentsSee.Size = new System.Drawing.Size(276, 28);
            this.tsmiStudentsSee.Text = "Просмотр учеников";
            this.tsmiStudentsSee.Click += new System.EventHandler(this.tsmiStudentsSee_Click);
            // 
            // tsmiStudentsAdd
            // 
            this.tsmiStudentsAdd.Name = "tsmiStudentsAdd";
            this.tsmiStudentsAdd.Size = new System.Drawing.Size(276, 28);
            this.tsmiStudentsAdd.Text = "Добавить ученика";
            this.tsmiStudentsAdd.Click += new System.EventHandler(this.tsmiStudentsAdd_Click);
            // 
            // tsmiStudentsRemove
            // 
            this.tsmiStudentsRemove.Name = "tsmiStudentsRemove";
            this.tsmiStudentsRemove.Size = new System.Drawing.Size(276, 28);
            this.tsmiStudentsRemove.Text = "Удалить ученика";
            this.tsmiStudentsRemove.Click += new System.EventHandler(this.tsmiStudentsRemove_Click);
            // 
            // tsmiTopics
            // 
            this.tsmiTopics.Name = "tsmiTopics";
            this.tsmiTopics.Size = new System.Drawing.Size(71, 28);
            this.tsmiTopics.Text = "Темы";
            this.tsmiTopics.Click += new System.EventHandler(this.tsmiTopics_Click);
            // 
            // tsmiSchedule
            // 
            this.tsmiSchedule.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiScheduleSee,
            this.tsmiScheduleEdit});
            this.tsmiSchedule.Name = "tsmiSchedule";
            this.tsmiSchedule.Size = new System.Drawing.Size(135, 28);
            this.tsmiSchedule.Text = "Расписание";
            // 
            // tsmiScheduleSee
            // 
            this.tsmiScheduleSee.Name = "tsmiScheduleSee";
            this.tsmiScheduleSee.Size = new System.Drawing.Size(300, 28);
            this.tsmiScheduleSee.Text = "Просмотр расписания";
            // 
            // tsmiScheduleEdit
            // 
            this.tsmiScheduleEdit.Name = "tsmiScheduleEdit";
            this.tsmiScheduleEdit.Size = new System.Drawing.Size(300, 28);
            this.tsmiScheduleEdit.Text = "Изменить расписание";
            // 
            // tsmiProfil
            // 
            this.tsmiProfil.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsmiProfil.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiProfilEdit,
            this.tsmiPasswordChange,
            this.tsmiProfilChange,
            this.tsmiExit});
            this.tsmiProfil.Name = "tsmiProfil";
            this.tsmiProfil.Size = new System.Drawing.Size(107, 28);
            this.tsmiProfil.Text = "Профиль";
            // 
            // tsmiProfilEdit
            // 
            this.tsmiProfilEdit.Name = "tsmiProfilEdit";
            this.tsmiProfilEdit.Size = new System.Drawing.Size(321, 28);
            this.tsmiProfilEdit.Text = "Редактировать профиль";
            this.tsmiProfilEdit.Click += new System.EventHandler(this.tsmiProfilEdit_Click);
            // 
            // tsmiPasswordChange
            // 
            this.tsmiPasswordChange.Name = "tsmiPasswordChange";
            this.tsmiPasswordChange.Size = new System.Drawing.Size(321, 28);
            this.tsmiPasswordChange.Text = "Сменить пароль";
            this.tsmiPasswordChange.Click += new System.EventHandler(this.tsmiPasswordChange_Click);
            // 
            // tsmiProfilChange
            // 
            this.tsmiProfilChange.Name = "tsmiProfilChange";
            this.tsmiProfilChange.Size = new System.Drawing.Size(321, 28);
            this.tsmiProfilChange.Text = "Сменить профиль";
            this.tsmiProfilChange.Click += new System.EventHandler(this.tsmiProfilChange_Click);
            // 
            // tsmiExit
            // 
            this.tsmiExit.Name = "tsmiExit";
            this.tsmiExit.Size = new System.Drawing.Size(321, 28);
            this.tsmiExit.Text = "Выйти";
            this.tsmiExit.Click += new System.EventHandler(this.tsmiExit_Click);
            // 
            // tsmiTeachers
            // 
            this.tsmiTeachers.Name = "tsmiTeachers";
            this.tsmiTeachers.Size = new System.Drawing.Size(170, 28);
            this.tsmiTeachers.Text = "Преподаватели";
            this.tsmiTeachers.Click += new System.EventHandler(this.tsmiTeachers_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(0, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1200, 48);
            this.label1.TabIndex = 1;
            this.label1.Text = "Электронный журнал";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(13, 107);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Поиск ученика";
            // 
            // tbStudentSearch
            // 
            this.tbStudentSearch.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbStudentSearch.Location = new System.Drawing.Point(168, 104);
            this.tbStudentSearch.Margin = new System.Windows.Forms.Padding(4);
            this.tbStudentSearch.Name = "tbStudentSearch";
            this.tbStudentSearch.Size = new System.Drawing.Size(298, 32);
            this.tbStudentSearch.TabIndex = 3;
            this.tbStudentSearch.TextChanged += new System.EventHandler(this.tbStudentSearch_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(547, 107);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 24);
            this.label3.TabIndex = 4;
            this.label3.Text = "Предмет";
            // 
            // cbSubject
            // 
            this.cbSubject.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbSubject.FormattingEnabled = true;
            this.cbSubject.Location = new System.Drawing.Point(647, 104);
            this.cbSubject.Margin = new System.Windows.Forms.Padding(4);
            this.cbSubject.Name = "cbSubject";
            this.cbSubject.Size = new System.Drawing.Size(148, 32);
            this.cbSubject.TabIndex = 5;
            this.cbSubject.SelectedIndexChanged += new System.EventHandler(this.cbSubject_SelectedIndexChanged);
            // 
            // dgvGrade
            // 
            this.dgvGrade.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGrade.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dgvGrade.Location = new System.Drawing.Point(15, 161);
            this.dgvGrade.Margin = new System.Windows.Forms.Padding(4);
            this.dgvGrade.Name = "dgvGrade";
            this.dgvGrade.RowHeadersWidth = 51;
            this.dgvGrade.Size = new System.Drawing.Size(780, 292);
            this.dgvGrade.TabIndex = 6;
            this.dgvGrade.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGrade_CellDoubleClick);
            this.dgvGrade.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvGrade_CellFormatting);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Id";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 125;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "ФИО";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Специализация";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 125;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Предмет";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.Width = 125;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Оценка";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            this.Column5.Width = 125;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Преподаватель";
            this.Column6.MinimumWidth = 6;
            this.Column6.Name = "Column6";
            this.Column6.Width = 125;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(825, 107);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 24);
            this.label4.TabIndex = 7;
            this.label4.Text = "Свойство ученика";
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.BackColor = System.Drawing.Color.Transparent;
            this.lblStudent.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblStudent.Location = new System.Drawing.Point(825, 161);
            this.lblStudent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(103, 24);
            this.lblStudent.TabIndex = 8;
            this.lblStudent.Text = "lblStudent";
            // 
            // lbStudent
            // 
            this.lbStudent.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbStudent.FormattingEnabled = true;
            this.lbStudent.ItemHeight = 24;
            this.lbStudent.Location = new System.Drawing.Point(831, 193);
            this.lbStudent.Margin = new System.Windows.Forms.Padding(4);
            this.lbStudent.Name = "lbStudent";
            this.lbStudent.Size = new System.Drawing.Size(343, 124);
            this.lbStudent.TabIndex = 9;
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(827, 434);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(0, 24);
            this.lblCount.TabIndex = 10;
            // 
            // tsmiGrades
            // 
            this.tsmiGrades.Name = "tsmiGrades";
            this.tsmiGrades.Size = new System.Drawing.Size(93, 28);
            this.tsmiGrades.Text = "Оценки";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 469);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.lbStudent);
            this.Controls.Add(this.lblStudent);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dgvGrade);
            this.Controls.Add(this.cbSubject);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbStudentSearch);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.Text = "Электронный журнал";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGrade)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmiStudents;
        private System.Windows.Forms.ToolStripMenuItem tsmiStudentsSee;
        private System.Windows.Forms.ToolStripMenuItem tsmiStudentsAdd;
        private System.Windows.Forms.ToolStripMenuItem tsmiStudentsRemove;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbStudentSearch;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbSubject;
        private System.Windows.Forms.DataGridView dgvGrade;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.ListBox lbStudent;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.ToolStripMenuItem tsmiProfil;
        private System.Windows.Forms.ToolStripMenuItem tsmiProfilEdit;
        private System.Windows.Forms.ToolStripMenuItem tsmiProfilChange;
        private System.Windows.Forms.ToolStripMenuItem tsmiTopics;
        private System.Windows.Forms.ToolStripMenuItem tsmiSchedule;
        private System.Windows.Forms.ToolStripMenuItem tsmiScheduleSee;
        private System.Windows.Forms.ToolStripMenuItem tsmiScheduleEdit;
        private System.Windows.Forms.ToolStripMenuItem tsmiPasswordChange;
        private System.Windows.Forms.ToolStripMenuItem tsmiExit;
        private System.Windows.Forms.ToolStripMenuItem tsmiTeachers;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.ToolStripMenuItem tsmiGrades;
    }
}

