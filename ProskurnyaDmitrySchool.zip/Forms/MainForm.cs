﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Forms;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace ProskurnyaDmitrySchool
{
    //Главное окно
    public partial class MainForm : Form
    {
        //Создаю список учеников
        public List<Student> students = new List<Student>();
        //Создаю экземпляр класса для использования его методов
        StudentsFromDb studentsFromDb = new StudentsFromDb();
        //Создаю список предметов
        public static List<Subject> subjects = new List<Subject>();
        //Создаю экземпляр класса для использования его методов
        SubjectsFromDb subjectsFromDb = new SubjectsFromDb();
        ProfilForm profilForm = new ProfilForm();
        AuthorizationForm authorizationForm = new AuthorizationForm();
        TeachersForm teachersForm = new TeachersForm();
        int count;
        //Конструктор
        public MainForm()
        {
            InitializeComponent();
            dgvGrade.Columns[0].DataPropertyName = "StudentNumber";
            dgvGrade.Columns[1].DataPropertyName = "StudentName";
            dgvGrade.Columns[2].DataPropertyName = "Specialization";
            dgvGrade.Columns[3].DataPropertyName = "SubjectName";
            dgvGrade.Columns[4].DataPropertyName = "Grade";
            dgvGrade.Columns[5].DataPropertyName = "TeacherName";
            dgvGrade.Columns[0].Visible = false;
        }
        //Загрузка главного окна
        private void MainForm_Load(object sender, EventArgs e)
        {
            ViewAllStudents();
            lblCount.Text = "Учеников: " + dgvGrade.Rows.Count.ToString() + " из " + count.ToString();
            //Выгружаю данные
            subjects = subjectsFromDb.LoadSubjects();
            //Добавляю первое значение для сброса фильтра
            subjects.Insert(0, new Subject(0, "Все предметы"));
            //Устанавливаю источник данных для комбобокса
            cbSubject.DataSource = subjects;
            //Устанавливаю параметры отображения и полученного значения
            cbSubject.DisplayMember = "SubjectName";
            cbSubject.ValueMember = "SubjectCode";
            switch (AuthorizationForm.currentTeacher.RoleId)
            {
                case 2:
                    tsmiProfilEdit.Visible = false;//Скрываю пункт Изменить профиль
                    tsmiPasswordChange.Visible = false;//Скрываю пункт Изменить пароль
                    break;
                case 3:
                    tsmiProfilEdit.Visible = false;//Скрываю пункт Изменить профиль
                    tsmiPasswordChange.Visible = false;//Скрываю пункт Изменить пароль
                    tsmiStudentsAdd.Visible = false;//Скрываю пункт Добавить ученика
                    tsmiStudentsRemove.Visible = false;//Скрываю пункт Удалить ученика
                    tsmiTopicAdd.Visible = false;//Скрываю пункт Добавить тему
                    tsmiTopicEdit.Visible = false;//Скрываю пункт Изменить тему
                    tsmiTopicRemove.Visible = false;//Скрываю пункт Удалить тему
                    tsmiScheduleEdit.Visible = false;//Скрываю пункт Изменить расписание
                    break;
            }
            tsmiProfil.Text = AuthorizationForm.currentTeacher.TeacherName;
        }
        //Метод вывода всех учеников
        private void ViewAllStudents()
        {
            students = studentsFromDb.LoadStudents();
            dgvGrade.DataSource = students;
            count = students.Count;
        }
        //Метод поиска учеников по начальным буквам
        private List<Student> SearchStudents(string tbStudentSearch)
        {
            //Создаю список результатов
            List<Student> studentSearch = new List<Student>();
            //Перебираю всех учеников и если какое-то начинается с нужных символов, то добавляю в список результатов
            foreach (Student item in students)
            {
                if (item.StudentName.StartsWith(tbStudentSearch))
                {
                    studentSearch.Add(item);
                }
            }
            return studentSearch;
        }
        //Метод вывода информации об ученике
        void PrintStudent(List<StudentInfo> studentInfo, string studentName)
        {
            ClearStudent();
            lblStudent.Text = studentName;
            foreach (StudentInfo student in studentInfo)
            {
                lbStudent.Items.Add("ФИО: " + student.StudentName);
                lbStudent.Items.Add("Класс: " + student.Specialization);
                lbStudent.Items.Add("Дата рождения: " + student.StudentDateOfBirth);
                lbStudent.Items.Add("Домашний адрес: " + student.StudentHomeAddress);
                lbStudent.Items.Add("Мобильный телефон: " + student.StudentPhoneNumber);
                lbStudent.Items.Add("Номер приказа: " + student.OrderNumber);
                lbStudent.Items.Add("Дата приказа: " + student.OrderDate);
            }
        }
        //Метод очистки полей
        private void ClearStudent()
        {
            lbStudent.Items.Clear();
            lblStudent.Text = "";
        }
        //Фильтрация по классу
        private void cbSubject_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearStudent();
            //Если выбран первый пункт, то реализую сброс фильтра
            if (cbSubject.SelectedIndex == 0)
            {
                ViewAllStudents();
                lblCount.Text = "Учеников: " + dgvGrade.Rows.Count.ToString() + " из " + count.ToString();
            }
            //Иначе запускаю метод фильтрации
            else
            {
                students = studentsFromDb.FilterStudentsBySubject(Convert.ToInt32(cbSubject.SelectedValue));
                dgvGrade.DataSource = students;
                lblCount.Text = "Учеников: " + dgvGrade.Rows.Count.ToString() + " из " + count.ToString();
            }
        }
        //Изменение поиска учеников
        private void tbStudentSearch_TextChanged(object sender, EventArgs e)
        {
            ClearStudent();
            dgvGrade.DataSource = SearchStudents(tbStudentSearch.Text);
            lblCount.Text = "Учеников: " + dgvGrade.Rows.Count.ToString() + " из " + count.ToString();
        }
        //Событие подсвечивания учеников по оценкам
        private void dgvGrade_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 5 && e.RowIndex != this.dgvGrade.NewRowIndex)
            {
                int value = (int)dgvGrade[4, e.RowIndex].Value;
                if (value == 2)
                {
                    dgvGrade.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Red;
                    dgvGrade.Rows[e.RowIndex].DefaultCellStyle.ForeColor = Color.White;
                }
                else
                {
                    dgvGrade.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.White;
                }
            }
        }
        //Событие двойного клика по ячейке
        private void dgvGrade_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //Определяю текущую строку
            int selectedRowIndex = dgvGrade.CurrentRow.Index;
            //Получаю список из БД по номеру ученика
            //Так как строки ДатаГрида идентичны строкам списка блюд, то получаю номер ученика из списка
            List<StudentInfo> studentInfo = studentsFromDb.StudentInfoFromDB(students[selectedRowIndex].StudentNumber);
            //Вывод информации ученика
            PrintStudent(studentInfo, students[selectedRowIndex].StudentName);
        }
        //Событие просмотра учеников
        private void tsmiStudentsSee_Click(object sender, EventArgs e)
        {
            StudentSeeForm studentSeeForm = new StudentSeeForm();
            studentSeeForm.ShowDialog();
        }
        //Событие добавления ученика
        private void tsmiStudentsAdd_Click(object sender, EventArgs e)
        {
            StudentAddForm studentAddForm = new StudentAddForm();
            studentAddForm.ShowDialog();
        }
        //Событие удаления ученика
        private void tsmiStudentsRemove_Click(object sender, EventArgs e)
        {
            int i = dgvGrade.CurrentRow.Index;
            int id = (int)dgvGrade[0, i].Value;
            if (dgvGrade.SelectedRows.Count > 0)
            {
                studentsFromDb.StudentRemove(id);
                ViewAllStudents();
            }
            else
            {
                MessageBox.Show("Ученик не указан!");
            }
        }
        /*
//Просмотр учеников
private void tsmiStudentsSee_Click(object sender, EventArgs e)
{
StudentSeeForm studentSeeForm = new StudentSeeForm();
studentSeeForm.Show();
}
//Добавить учеников
private void tsmiStudentsAdd_Click(object sender, EventArgs e)
{
StudentAddForm studentAddForm = new StudentAddForm();
studentAddForm.Show();
}
//Преподаватели
private void tsmiTeachers_Click(object sender, EventArgs e)
{
teachersForm.Show();
}
//Редактировать профиль
private void tsmiEditProfil_Click(object sender, EventArgs e)
{
DialogResult result = profilForm.ShowDialog();
if (result == DialogResult.OK)
{
tsmiProfil.Text = AuthorizationForm.currentTeacher.TeacherName;
}
}
//Изменить пароль
private void tsmiPasswordChange_Click(object sender, EventArgs e)
{
PasswordForm passwordForm = new PasswordForm();
passwordForm.Show();
}
//Изменить профиль
private void tsmiProfilChange_Click(object sender, EventArgs e)
{
this.Hide();
authorizationForm.ShowDialog(this);
}
//Выход
private void tsmiExit_Click(object sender, EventArgs e)
{
Application.Exit();
}*/
    }
}