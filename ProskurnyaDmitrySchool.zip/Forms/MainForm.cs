﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool
{
    public partial class MainForm : Form
    {
        public List<Student> students = new List<Student>();
        StudentsFromDb studentsFromDb = new StudentsFromDb();
        public static List<Subject> subjects = new List<Subject>();
        SubjectsFromDb subjectsFromDb = new SubjectsFromDb();
        public MainForm()
        {
            InitializeComponent();
            dgvGrade.Columns[0].DataPropertyName = "StudentNumber";
            dgvGrade.Columns[1].DataPropertyName = "StudentName";
            dgvGrade.Columns[2].DataPropertyName = "Specialization";
            dgvGrade.Columns[3].DataPropertyName = "SubjectName";
            dgvGrade.Columns[4].DataPropertyName = "Grade";
            dgvGrade.Columns[0].Visible = false;
        }
        private void ViewAllStudents()
        {
            students = studentsFromDb.LoadStudents();
            dgvGrade.DataSource = students;
        }
        private void MainForm_Load(object sender, EventArgs e)
        {
            ViewAllStudents();
            subjects = subjectsFromDb.LoadSubjects();
            subjects.Insert(0, new Subject(0, "Все предметы"));
            cbSubject.DataSource = subjects;
            cbSubject.DisplayMember = "SubjectName";
            cbSubject.ValueMember = "SubjectCode";
        }
        private void cbSubject_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbSubject.SelectedIndex == 0)
            {
                ViewAllStudents();
            }
            else
            {
                students = studentsFromDb.FiltrStudentsBySubject(Convert.ToInt32(cbSubject.SelectedValue));
                dgvGrade.DataSource = students;
            }
        }
        private List<Student> SearchStudents(string tbStudentSearch)
        {
            List<Student> studentSearch = new List<Student>();
            foreach (Student item in students)
            {
                if (item.StudentName.StartsWith(tbStudentSearch))
                {
                    studentSearch.Add(item);
                }
            }
            return studentSearch;
        }
        private void tbStudentSearch_TextChanged(object sender, EventArgs e)
        {
            dgvGrade.DataSource = SearchStudents(tbStudentSearch.Text);
        }
        void PrintStudent(List<StudentInfo> studentInfo, string studentName)
        {
            ClearStudent();
            lblStudent.Text = studentName;
            foreach (StudentInfo student in studentInfo)
            {
                lbStudent.Items.Add("ФИО: " + student.StudentName);
                lbStudent.Items.Add("Класс: " + student.Specialization);
                lbStudent.Items.Add("Дата рождения: " + student.StudentDateOfBirth);
                lbStudent.Items.Add("Домашний адрес: " + student.StudentHomeAddress);
                lbStudent.Items.Add("Мобильный телефон: " + student.StudentPhoneNumber);
                lbStudent.Items.Add("Номер приказа: " + student.OrderNumber);
                lbStudent.Items.Add("Дата приказа: " + student.OrderDate);
            }
        }
        void ClearStudent()
        {
            lbStudent.Items.Clear();
            lblStudent.Text = "";
        }
        private void dgvGrade_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRowIndex = dgvGrade.CurrentRow.Index;
            List<StudentInfo> studentInfo = studentsFromDb.StudentInfoFromDB(students[selectedRowIndex].StudentNumber);
            PrintStudent(studentInfo, students[selectedRowIndex].StudentName);
        }
        private void tsmiStudentsRemove_Click(object sender, EventArgs e)
        {
            int i = dgvGrade.CurrentRow.Index;
            int id = (int)dgvGrade[0, i].Value;
            if (dgvGrade.SelectedRows.Count > 0 )
            {
                studentsFromDb.StudentRemove(id);
                ViewAllStudents();
            }
            else
            {
                MessageBox.Show("Ученик не указан!");
            }
        }
    }
}