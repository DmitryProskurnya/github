﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class PasswordForm : Form
    {
        TeachersFromDb teachersFromDb = new TeachersFromDb();
        public PasswordForm()
        {
            InitializeComponent();
        }
        private void btnChange_Click(object sender, EventArgs e)
        {
            if (AuthorizationForm.currentTeacher.TeacherPassword != Verification.GetSHA512Hash(tbOldPassword.Text))
            {
                MessageBox.Show("ОШИБКА: Неверно введён пароль!");
                return;
            }
            if (tbNewPassword.Text == "")
            {
                MessageBox.Show("ОШИБКА: Введите новый пароль!");
                return;
            }
            bool rez = teachersFromDb.CheckPassword(tbNewPassword.Text, tbCheckPassword.Text);
            if (!rez)
            {
                return;
            }
            else
            {
                AuthorizationForm.currentTeacher.TeacherPassword = tbNewPassword.Text;
                teachersFromDb.TeacherUpdatePassword(AuthorizationForm.currentTeacher);
                this.Close();
            }
        }
    }
}
