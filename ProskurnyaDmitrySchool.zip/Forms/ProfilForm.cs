﻿using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class ProfilForm : Form
    {
        TeachersFromDb teachersFromDb = new TeachersFromDb();
        public ProfilForm()
        {
            InitializeComponent();
        }
        private void ProfilForm_Load(object sender, EventArgs e)
        {
            tbName.Text = AuthorizationForm.currentTeacher.TeacherName;
            dtpBirthday.Value = AuthorizationForm.currentTeacher.TeacherDateOfBirth;
            tbPhone.Text = AuthorizationForm.currentTeacher.TeacherPhoneNumber;
            tbAddress.Text = AuthorizationForm.currentTeacher.TeacherHomeAddress;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (tbName.Text != "")
            {
                AuthorizationForm.currentTeacher.TeacherName = tbName.Text;
                AuthorizationForm.currentTeacher.TeacherDateOfBirth = dtpBirthday.Value;
                AuthorizationForm.currentTeacher.TeacherPhoneNumber = tbPhone.Text;
                AuthorizationForm.currentTeacher.TeacherHomeAddress = tbAddress.Text;
                teachersFromDb.TeacherUpdateProfil(AuthorizationForm.currentTeacher);
            }
        }
    }
}