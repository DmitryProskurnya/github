﻿using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class ProfilForm : Form
    {
        TeachersFromDb teachersFromDb = new TeachersFromDb();
        public ProfilForm()
        {
            InitializeComponent();
        }
        private void ProfilForm_Load(object sender, EventArgs e)
        {
            tbName.Text = AuthorizationForm.currentTeacher.TeacherName;
            dtpBirthday.Value = AuthorizationForm.currentTeacher.TeacherDateOfBirth;
            tbAddress.Text = AuthorizationForm.currentTeacher.TeacherHomeAddress;
            tbPhone.Text = AuthorizationForm.currentTeacher.TeacherPhoneNumber;
            tbEmail.Text = AuthorizationForm.currentTeacher.TeacherEmail;
            tbPassportSeries.Text = AuthorizationForm.currentTeacher.TeacherPassportSeries;
            tbPassportId.Text = AuthorizationForm.currentTeacher.TeacherPassportId;
            tbIssuedBy.Text = AuthorizationForm.currentTeacher.PassportIssuedBy;
            dtpDateOfIssue.Value = AuthorizationForm.currentTeacher.PassportDateOfIssue;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (tbName.Text != "")
            {
                AuthorizationForm.currentTeacher.TeacherName = tbName.Text;
                AuthorizationForm.currentTeacher.TeacherDateOfBirth = dtpBirthday.Value;
                AuthorizationForm.currentTeacher.TeacherPhoneNumber = tbPhone.Text;
                AuthorizationForm.currentTeacher.TeacherHomeAddress = tbAddress.Text;
                teachersFromDb.TeacherUpdateProfil(AuthorizationForm.currentTeacher);
            }
            if (rbYes.Checked)
            {
                AuthorizationForm.currentTeacher.TeacherEmail = tbEmail.Text;
                AuthorizationForm.currentTeacher.TeacherPassportSeries = tbPassportSeries.Text;
                AuthorizationForm.currentTeacher.TeacherPassportId = tbPassportId.Text;
                AuthorizationForm.currentTeacher.PassportIssuedBy = tbIssuedBy.Text;
                AuthorizationForm.currentTeacher.PassportDateOfIssue = dtpDateOfIssue.Value;
                teachersFromDb.TeacherUpdateProfil(AuthorizationForm.currentTeacher);
            }
        }
    }
}