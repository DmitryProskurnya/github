﻿using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class RegistrationForm : Form
    {
        TeachersFromDb teachersFromDb = new TeachersFromDb();
        public RegistrationForm()
        {
            InitializeComponent();
        }
        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (tbName.Text == "" || tbLogin.Text == "" || tbPassword.Text == "" || tbCheckPassword.Text == "")
            {
                MessageBox.Show("Необходимо заполнить все поля!");
                return;
            }
            bool rez = teachersFromDb.CheckPassword(tbPassword.Text, tbCheckPassword.Text);
            if (!rez) return;
            else { }
            if (teachersFromDb.CheckTeacher(tbCheckPassword.Text))
            {
                teachersFromDb.TeacherAdd(tbName.Text, tbLogin.Text, tbPassword.Text);
            }
            else return;
        }
    }
}