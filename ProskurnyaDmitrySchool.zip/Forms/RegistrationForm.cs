﻿using ProskurnyaDmitrySchool.Models;
using System;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class RegistrationForm : Form
    {
        TeachersFromDb teachersFromDb = new TeachersFromDb();
        public RegistrationForm()
        {
            InitializeComponent();
        }
        private void btnRegister_Click(object sender, EventArgs e)
        {
            //Проверка - все ли поля заполнены
            if (tbName.Text == "" || tbLogin.Text == "" || tbPassword.Text == "" || tbCheckPassword.Text == "")
            {
                MessageBox.Show("Необходимо заполнить все поля!");
                return;
            }
            //Проверка на корректность пароля
            bool rez = teachersFromDb.CheckPassword(tbPassword.Text, tbCheckPassword.Text);
            if (!rez) return;
            //Проверяю наличие преподавателя с таким логином. Если Существует - возвращает false
            //Если нет - true, тогда добавляем преподавателя
            if (teachersFromDb.CheckTeacher(tbCheckPassword.Text))
            {
                teachersFromDb.TeacherAdd(tbLogin.Text, tbPassword.Text, tbName.Text);
                MainForm mainForm = new MainForm();
                mainForm.Show();
                this.Hide();
            }
            else return;
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
            AuthorizationForm authorizationForm = new AuthorizationForm();
            authorizationForm.Show();
        }
    }
}