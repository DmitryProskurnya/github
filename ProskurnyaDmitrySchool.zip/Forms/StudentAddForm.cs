﻿using ProskurnyaDmitrySchool.Models;
using System;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class StudentAddForm : Form
    {
        StudentsFromDb studentsFromDb = new StudentsFromDb();
        public StudentAddForm()
        {
            InitializeComponent();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (tbClassNumber.Text == "" || tbName.Text == "" || dtpBirthday.Text == "" || tbAddress.Text == "" || tbPhone.Text == "" || tbOrder.Text == "" || dtpOrder.Text == "")
            {
                MessageBox.Show("ОШИБКА: Необходимо заполнить все поля!");
                return;
            }
            else
            {
                studentsFromDb.StudentAdd(tbClassNumber.Text, tbName.Text, dtpBirthday.Text, tbAddress.Text, tbPhone.Text, tbOrder.Text, dtpOrder.Text);
            }
        }
    }
}