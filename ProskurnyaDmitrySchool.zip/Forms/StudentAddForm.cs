﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class StudentAddForm : Form
    {
        //Создаю экземпляр класса для использования его методов
        StudentsFromDb studentsFromDb = new StudentsFromDb();
        //Создаю список класса
        public static List<Class> classes = new List<Class>();
        //Создаю экземпляр класса для использования его методов
        ClassesFromDb classesFromDb = new ClassesFromDb();
        public StudentAddForm()
        {
            InitializeComponent();
        }
        private void StudentAddForm_Load(object sender, EventArgs e)
        {
            //Выгружаю данные
            classes = classesFromDb.LoadClasses();
            //Добавляю первое значение для сброса фильтра
            classes.Insert(0, new Class(0, "Классы"));
            //Устанавливаю источник данных для комбобокса
            cbClass.DataSource = classes;
            //Устанавливаю параметры отображения и полученного значения
            cbClass.DisplayMember = "Specialization";
            cbClass.ValueMember = "ClassNumber";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (tbPhone.Text.Length > 11)
            {
                MessageBox.Show("ОШИБКА: число цифр в номере не должно превышать 11!");
                return;
            }
            if (cbClass.ValueMember == "" || tbName.Text == "" || dtpBirthday.Text == "" || tbAddress.Text == "" || tbPhone.Text == "" || tbOrder.Text == "" || dtpOrder.Text == "")
            {
                MessageBox.Show("ОШИБКА: Необходимо заполнить все поля!");
                return;
            }
            else
            {
                studentsFromDb.StudentAdd(Convert.ToInt32(cbClass.ValueMember), tbName.Text, dtpBirthday.Text, tbAddress.Text, tbPhone.Text, Convert.ToInt32(tbOrder.Text), dtpOrder.Text);
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}