﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class StudentSeeForm : Form
    {
        //Создаю список учеников
        public List<StudentInfo> students = new List<StudentInfo>();
        //Создаю экземпляр класса для использования его методов
        StudentsFromDb studentsFromDb = new StudentsFromDb();
        public StudentSeeForm()
        {
            InitializeComponent();
            dgvStudent.Columns[0].DataPropertyName = "StudentNumber";
            dgvStudent.Columns[1].DataPropertyName = "Specialization";
            dgvStudent.Columns[2].DataPropertyName = "StudentName";
            dgvStudent.Columns[3].DataPropertyName = "StudentDateOfBirth";
            dgvStudent.Columns[4].DataPropertyName = "StudentHomeAddress";
            dgvStudent.Columns[5].DataPropertyName = "StudentPhoneNumber";
            dgvStudent.Columns[6].DataPropertyName = "OrderNumber";
            dgvStudent.Columns[7].DataPropertyName = "OrderDate";
            dgvStudent.Columns[0].Visible = false;
        }
        //Загрузка окна просмотра учеников
        private void StudentSeeForm_Load(object sender, EventArgs e)
        {
            ViewAllStudents();
        }
        //Метод вывода всех учеников
        private void ViewAllStudents()
        {
            students = studentsFromDb.LoadStudentsForDgvStudent();
            dgvStudent.DataSource = students;
        }
        //Событие добавления ученика
        private void btnAdd_Click(object sender, EventArgs e)
        {
            StudentAddForm studentAddForm = new StudentAddForm();
            studentAddForm.ShowDialog();
        }
        //Событие удаления ученика
        private void btnRemove_Click(object sender, EventArgs e)
        {
            int i = dgvStudent.CurrentRow.Index;
            int id = (int)dgvStudent[0, i].Value;
            if (dgvStudent.SelectedRows.Count > 0)
            {
                studentsFromDb.StudentRemove(id);
                ViewAllStudents();
            }
            else
            {
                MessageBox.Show("Ученик не указан!");
            }
        }
        //Событие выхода из окна
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}