﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class TeachersForm : Form
    {
        public List<Teacher> teachers = new List<Teacher>();
        TeachersFromDb teachersFromDb = new TeachersFromDb();
        Teacher selectedteacher = null;
        public TeachersForm()
        {
            InitializeComponent();
            dgvTeacher.Columns[0].DataPropertyName = "TeacherName";
            dgvTeacher.Columns[1].DataPropertyName = "RoleId";
            dgvTeacher.Columns[2].DataPropertyName = "TeacherPersonnelNumber";
            dgvTeacher.Columns[3].DataPropertyName = "TeacherDateOfBirth";
            dgvTeacher.Columns[4].DataPropertyName = "TeacherLogin";
            dgvTeacher.Columns[5].DataPropertyName = "TeacherPassword";
            dgvTeacher.Columns[6].DataPropertyName = "TeacherPhoneNumber";
            dgvTeacher.Columns[7].DataPropertyName = "TeacherHomeAddress";
            dgvTeacher.Columns[2].Visible = false;
            dgvTeacher.Columns[3].Visible = false;
            dgvTeacher.Columns[4].Visible = false;
            dgvTeacher.Columns[5].Visible = false;
            dgvTeacher.Columns[6].Visible = false;
            dgvTeacher.Columns[7].Visible = false;
        }
        private void ViewAllTeachers()
        {
            teachers = teachersFromDb.LoadTeachers();
            dgvTeacher.DataSource = teachers;
        }
        private void TeachersForm_Load(object sender, EventArgs e)
        {
            ViewAllTeachers();
            tbName.Enabled = false;
            dtpBirthday.Enabled = false;
            tbAddress.Enabled = false;
            tbPhone.Enabled = false;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            RegistrationForm registrationForm = new RegistrationForm();
            registrationForm.ShowDialog();
            ViewAllTeachers();
        }
        private void btnRemove_Click(object sender, EventArgs e)
        {
            int i = dgvTeacher.CurrentRow.Index;
            int id = (int)dgvTeacher[0, i].Value;
            if (dgvTeacher.SelectedRows.Count > 0)
            {
                teachersFromDb.TeacherRemove(id);
                ViewAllTeachers();
            }
            else
            {
                MessageBox.Show("ОШИБКА: Строка не указана!");
            }
        }
        private void dgvTeacher_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            int k = dgvTeacher.CurrentCell.RowIndex;
            selectedteacher = teachers[k];
            tbName.Text = selectedteacher.TeacherName;
            dtpBirthday.Value = selectedteacher.TeacherDateOfBirth;
            tbAddress.Text = selectedteacher.TeacherHomeAddress;
            tbPhone.Text = selectedteacher.TeacherPhoneNumber;
            int i = selectedteacher.RoleId - 1;
            cbRole.SelectedIndex = i;
        }
        private void cbRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (true)
            {
                btnChange.Enabled = true;
            }
        }
        private void btnChange_Click(object sender, EventArgs e)
        {
            int i = dgvTeacher.CurrentRow.Index;
            int id = (int)dgvTeacher[0, i].Value;
            int role = (int)cbRole.SelectedIndex + 1;
            teachersFromDb.TeacherUpdateRole(role, id);
            ViewAllTeachers();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}