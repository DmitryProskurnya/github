﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class TopicAddForm : Form
    {
        //Создаю экземпляр класса для использования его методов
        TopicsFromDb topicsFromDb = new TopicsFromDb();
        //Создаю список предмета
        public static List<Subject> subjects = new List<Subject>();
        //Создаю экземпляр класса для использования его методов
        SubjectsFromDb subjectsFromDb = new SubjectsFromDb();
        public TopicAddForm()
        {
            InitializeComponent();
        }
        private void TopicAddForm_Load(object sender, EventArgs e)
        {
            //Выгружаю данные
            subjects = subjectsFromDb.LoadSubjects();
            //Добавляю первое значение для сброса фильтра
            subjects.Insert(0, new Subject(0, "Все предметы"));
            //Устанавливаю источник данных для комбобокса
            cbSubject.DataSource = subjects;
            //Устанавливаю параметры отображения и полученного значения
            cbSubject.DisplayMember = "SubjectName";
            cbSubject.ValueMember = "SubjectCode";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (cbSubject.ValueMember == "" || tbHours.Text == "" || tbName.Text == "")
            {
                MessageBox.Show("ОШИБКА: Необходимо заполнить все поля!");
                return;
            }
            else
            {
                topicsFromDb.TopicAdd(Convert.ToInt32(cbSubject.ValueMember), Convert.ToInt32(tbHours.Text), tbName.Text);
            }
        }
    }
}