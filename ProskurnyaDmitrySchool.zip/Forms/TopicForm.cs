﻿using ProskurnyaDmitrySchool.Classes;
using ProskurnyaDmitrySchool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Forms
{
    public partial class TopicForm : Form
    {
        //Создаю список тем
        public List<Topic> topics = new List<Topic>();
        //Создаю экземпляр класса для использования его методов
        TopicsFromDb topicsFromDb = new TopicsFromDb();
        public TopicForm()
        {
            InitializeComponent();
            dgvTopic.Columns[0].DataPropertyName = "TopicName";
            dgvTopic.Columns[1].DataPropertyName = "SubjectName";
            dgvTopic.Columns[2].DataPropertyName = "HoursToStudy";
            dgvTopic.Columns[3].DataPropertyName = "Type";
            dgvTopic.Columns[0].Visible = false;
        }
        //Загрузка окна просмотра тем
        private void TopicForm_Load(object sender, EventArgs e)
        {
            ViewAllTopics();
        }
        //Метод вывода всех тем
        private void ViewAllTopics()
        {
            topics = topicsFromDb.LoadTopics();
            dgvTopic.DataSource = topics;
        }
        //Событие добавления темы
        private void btnAdd_Click(object sender, EventArgs e)
        {
            TopicAddForm topicAddForm = new TopicAddForm();
            topicAddForm.ShowDialog();
        }
        //Событие редактирования темы
        private void btnEdit_Click(object sender, EventArgs e)
        {
            TopicEditForm topicEditForm = new TopicEditForm();
            topicEditForm.ShowDialog();
        }
        //Событие удаления темы
        private void btnRemove_Click(object sender, EventArgs e)
        {
            int i = dgvTopic.CurrentRow.Index;
            int id = (int)dgvTopic[0, i].Value;
            if (dgvTopic.SelectedRows.Count > 0)
            {
                topicsFromDb.TopicRemove(id);
                ViewAllTopics();
            }
            else
            {
                MessageBox.Show("ОШИБКА: Тема не указана!");
            }
        }
        //Событие выхода из окна
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}