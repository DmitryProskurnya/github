﻿using Npgsql;
using ProskurnyaDmitrySchool.Classes;
using System.Collections.Generic;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Models
{
    internal class ClassesFromDb
    {
        //Метод выгрузки данных из таблицы Классы
        public List<Class> LoadClasses()
        {
            List<Class> classes = new List<Class>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select class_number, specialization from subject";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        classes.Add(new Class((int)reader[0], reader[1].ToString(), (int)reader[2]));
                    }
                    reader.Close();
                }
                return classes;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return classes;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}