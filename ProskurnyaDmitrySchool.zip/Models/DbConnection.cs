﻿namespace ProskurnyaDmitrySchool.Models
{
    internal class DbConnection
    {
        internal static string connectionStr = @"Server = 172.20.105.123; Port = 5432; DataBase = SchoolProskurnya; User Id = 9po11-21-18; Password = zee9aeNg";
        //internal static string connectionStr = @"Server=192.168.0.2; Port=5432; DataBase=SchoolProskurnya; User Id=9po11-21-18; Password=zee9aeNg";
    }
}