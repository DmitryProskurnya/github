﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ProskurnyaDmitrySchool.Models
{
    internal class DbConnection
    {
        internal static string connectionStr = @"Server=172.20.105.123; Port=5432; DataBase=ProskurnyaDmitrySchool; User Id=9po11-21-18; Password=zee9aeNg";
    }
}