﻿using Npgsql;
using ProskurnyaDmitrySchool.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
namespace ProskurnyaDmitrySchool.Models
{
    internal class StudentsFromDb
    {
        //Метод загрузки всех данных из таблицы Ученики, возвращает список объектов типа Ученики
        public List<Student> LoadStudents()
        {
            List<Student> students = new List<Student>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select student.student_number, student_name, specialization, subject_name, grade.grades, teacher_name from student, class, subject, grade, "
                    + "teacher where student.student_number = grade.student_number and student.class_number = class.class_number and class.class_number = subject.class_number "
                    + "and teacher.teacher_personnel_number = subject.teacher_personnel_number group by student.student_number, specialization, subject_name, grade.grades, "
                    + "teacher.teacher_name order by subject_name";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        //Добавляю полученную строку в список, путём создания нового экземпляра класса Ученики
                        students.Add(new Student((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), (int)reader[4], reader[5].ToString()));
                    }
                }
                reader.Close();
                return students;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return students;
            }
            finally
            {
                connection.Close();
            }
        }
        //Метод фильтрации данных
        public List<Student> FilterStudentsBySubject(int subjectCode)
        {
            List<Student> students = new List<Student>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select student.student_number, student_name, specialization, subject_name, grade.grades, teacher_name from student, class, subject, grade, "
                    + "teacher where student.student_number = grade.student_number and student.class_number = class.class_number and class.class_number = subject.class_number "
                    + "and subject.subject_code = @subjectCode and teacher.teacher_personnel_number = subject.teacher_personnel_number group by student.student_number, "
                    + "specialization, subject_name, grade.grades, teacher.teacher_name order by subject_name";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                command.Parameters.AddWithValue("@subjectCode", subjectCode);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        students.Add(new Student((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), (int)reader[4], reader[5].ToString()));
                    }
                }
                reader.Close();
                return students;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return students;
            }
            finally
            {
                connection.Close();
            }
        }
        //Метод получения информации об ученике
        public List<StudentInfo> StudentInfoFromDB(int studentNumber)
        {
            List<StudentInfo> studentInfo = new List<StudentInfo>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select student_number, specialization, student_name, student_date_of_birth, student_home_address, student_phone_number,"
                    + " order_number, order_date from student, class where student_number = @studentNumber and student.class_number = class.class_number";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                command.Parameters.AddWithValue("@studentNumber", studentNumber);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        studentInfo.Add(new StudentInfo(studentNumber, reader[1].ToString(), reader[2].ToString(), Convert.ToDateTime(reader[3]), reader[4].ToString(), reader[5].ToString(), (int)reader[6], Convert.ToDateTime(reader[7])));
                    }
                }
                reader.Close();
                return studentInfo;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
                return studentInfo;
            }
            finally { connection.Close(); }
        }
        //Метод добавления ученика
        public void StudentAdd(int classNumber, string name, string birthday, string address, string phone, int orderNumber, string orderDate)
        {
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            connection.Open();
            NpgsqlTransaction transaction = connection.BeginTransaction();
            NpgsqlCommand cmd = connection.CreateCommand();
            cmd.Transaction = transaction;
            try
            {
                cmd.CommandText = "insert into student (class_number, student_name, student_date_of_birth, "
                    + "student_home_address, student_phone_number, order_number, order_date) values (@ClassNumber, "
                    + "@StudentName, @StudentDateOfBirth, @StudentHomeAddress, @StudentPhoneNumber, "
                    + "@OrderNumber, @OrderDate)";
                cmd.Parameters.AddWithValue("@ClassNumber", classNumber);
                cmd.Parameters.AddWithValue("@StudentName", name);
                cmd.Parameters.AddWithValue("@StudentDateOfBirth", birthday);
                cmd.Parameters.AddWithValue("@StudentHomeAddress", address);
                cmd.Parameters.AddWithValue("@StudentPhoneNumber", phone);
                cmd.Parameters.AddWithValue("@OrderNumber", orderNumber);
                cmd.Parameters.AddWithValue("@OrderDate", orderDate);
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Ученик(ца) добавлен(а)!");
                }
                else
                {
                    MessageBox.Show("ОШИБКА ЗАПИСИ!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        //Метод изменения ученика
        public void StudentUpdate(StudentInfo student)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "update student set student_name = @Name, teacher_date_of_birth = @DateOfBirth, "
                    + "student_home_address = @HomeAddress, student_phone_number = @PhoneNumber where student_number = "
                    + "@StudentNumber";
                NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                cmd.Parameters.AddWithValue("Name", student.StudentName);
                cmd.Parameters.AddWithValue("DateOfBirth", student.StudentDateOfBirth);
                cmd.Parameters.AddWithValue("HomeAddress", student.StudentHomeAddress);
                cmd.Parameters.AddWithValue("PhoneNumber", student.StudentPhoneNumber);
                cmd.Parameters.AddWithValue("StudentNumber", student.StudentNumber);
                int i = cmd.ExecuteNonQuery();
                if (i == 1) { MessageBox.Show("Данные обновлены!"); }
                else MessageBox.Show("ОШИБКА ЗАПИСИ!");
            }
            catch (NpgsqlException ex) { MessageBox.Show(ex.Message); return; }
            connect.Close();
        }
        //Метод удаления ученика
        public void StudentRemove(int studentNumber)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "delete from grade where student_number = @studentNumber; delete from student where student_number = @studentNumber";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("studentNumber", studentNumber);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("ОШИБКА ЗАПИСИ!");
                }
                else
                {
                    MessageBox.Show("Ученик удалён!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        //Метод загрузки всех данных из таблицы ИнфоУченики
        public List<StudentInfo> LoadStudentsForDgvStudent()
        {
            List<StudentInfo> students = new List<StudentInfo>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select student_number, specialization, student_name, student_date_of_birth, student_home_address, student_phone_number,"
                    + " order_number, order_date from student, class where student.class_number = class.class_number";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        //Добавляю полученную строку в список, путём создания нового экземпляра класса ИнфоУченики
                        students.Add(new StudentInfo((int)reader[0], reader[1].ToString(), reader[2].ToString(), Convert.ToDateTime(reader[3]), reader[4].ToString(), reader[5].ToString(), (int)reader[6], Convert.ToDateTime(reader[7])));
                    }
                }
                reader.Close();
                return students;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return students;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}