﻿using Npgsql;
using ProskurnyaDmitrySchool.Classes;
using System.Collections.Generic;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Models
{
    class SubjectsFromDb
    {
        //Метод выгрузки данных из таблицы Предметы
        public List<Subject> LoadSubjects()
        {
            List<Subject> subjects = new List<Subject>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select subject_code, subject_name from subject";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        subjects.Add(new Subject((int)reader[0], reader[1].ToString()));
                    }
                    reader.Close();
                }
                return subjects;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return subjects;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}