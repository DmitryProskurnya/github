﻿using Npgsql;
using ProskurnyaDmitrySchool.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Models
{
    class TeachersFromDb
    {
        public Teacher GetTeacher(string login, string password)
        {
            Teacher teacher = null;
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();
                    string sqlExp = "select * from teacher where teacher_login = @login";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("login", login);
                    NpgsqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        if (password != "")
                        {
                            if (Verification.VerifySHA512Hash(password, (string)reader["TeacherPassword"]))
                            {
                                teacher = new Teacher((int)reader[0], reader[1].ToString(), Convert.ToDateTime(reader[2]), reader[3].ToString(), reader[4].ToString(), (int)reader[5], reader[6].ToString(), reader[7].ToString());
                            }
                            else
                            {
                                MessageBox.Show("Неверный пароль!");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Нет такого пользователя!");
                    }
                    return teacher;
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return teacher;
            }
        }
    }
}