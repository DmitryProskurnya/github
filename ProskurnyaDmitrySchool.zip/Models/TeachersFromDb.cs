﻿using Npgsql;
using ProskurnyaDmitrySchool.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Models
{
    internal class TeachersFromDb
    {
        //Метод получения данных о преподавателе по логину и пароле
        public Teacher GetTeacher(string login, string password)
        {
            Teacher teacher = null;
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();
                    //Получаю данные по вводному логину
                    string sqlExp = "select teacher.teacher_personnel_number, role_id, teacher_login, teacher_password, teacher_name, teacher_date_of_birth, "
                        + "teacher_home_address, teacher_phone_number, teacher_email, teacher_passport_series, teacher_passport_id, passport_issued_by, "
                        + "passport_date_of_issue from teacher inner join datateacher on teacher.teacher_personnel_number = datateacher.teacher_personnel_number "
                        + "where teacher_login = @login";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("login", login);
                    //Выполняю запрос
                    NpgsqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)//Если запись с таким логином существует
                    {
                        reader.Read();//Считываю данные
                        //Шифрую пароль, введенный пользователю и сравниваю со значению из БД
                        if (password != "")
                        {
                            //Если пароли не совпадают
                            if (Verification.VerifySHA512Hash(password, (string)reader["teacher_password"]))
                            {
                                //Проверка даты, еси она не заполнена, устанавливаю текущую, если заполнена - извлекаю
                                DateTime dateOfBirth = DateTime.Now;
                                if (!(reader[2] is DBNull))
                                {
                                    dateOfBirth = Convert.ToDateTime(reader[5]);
                                }
                                //Заполняю данные о преподавателе
                                teacher = new Teacher((int)reader[0], (int)reader[1], reader[2].ToString(), reader[3].ToString(), reader[4].ToString(), dateOfBirth,
                                    reader[6].ToString(), reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(), reader[11].ToString(),
                                    Convert.ToDateTime(reader[12]));
                            }
                            else
                            {
                                MessageBox.Show("ОШИБКА: Неверный пароль!");//Если пароли совпадают, то открываю нужную форму в соответсвии с ролью
                            }
                        }
                    }
                    else//Если результат запроса пустой, то нет такого логина
                    {
                        MessageBox.Show("ОШИБКА: Нет такого пользователя!");
                    }
                    return teacher;
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return teacher;
            }
        }
        //Метод проверки пароля на соответсвтвие требованиям
        public bool CheckPassword(string password, string passRepeat)
        {
            if (password.Length < 6)
            {
                MessageBox.Show("ОШИБКА: Длина пароля не может быть меньше 6 символов!");
                return false;
            }
            else
            {
                bool f, f1, f2;
                f = f1 = f2 = false;
                for (int i = 0; i < password.Length; i++)
                {
                    if (Char.IsDigit(password[i]))
                    {
                        f1 = true;
                    }
                    if (Char.IsUpper(password[i]))
                    {
                        f2 = true;
                    }
                    if (f1 && f2)
                    {
                        break;
                    }
                }
                if (!(f1 && f2))
                {
                    MessageBox.Show("ОШИБКА: Пароль должен содержать хотя бы одну цифру и одну заглавную букву!");
                    return f1 && f2;
                }
                else
                {
                    string simbol = "!@#$%^";
                    for (int i = 0; i < password.Length; i++)
                    {
                        for (int j = 0; j < simbol.Length; j++)
                        {
                            if (password[i] == simbol[j])
                            {
                                f = true;
                                break;
                            }
                        }
                    }
                    if (!f)
                    {
                        MessageBox.Show("ОШИБКА: Пароль должен содержать один из символов '!@#$%^'!");
                    }
                    if ((password == passRepeat) && f)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("ОШИБКА: Неверно потверждён пароль!");
                        return false;
                    }
                }
            }
        }
        //Метод проверки - существует ли пользователь с таким логином, если существует - возвращает нет
        //Если нет - да
        public bool CheckTeacher(string login)
        {
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();
                    //Запрос на проверку уникальности логина
                    string sqlExp = "select teacher_login from teacher where teacher_login = @login";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("@login", login);
                    NpgsqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)//Если запрос вернет хотя бы одну строку, то такой логин не подходит
                    {
                        MessageBox.Show("ОШИБКА: Такой логин уже есть!");
                        return false;
                    }
                    else
                    {
                        reader.Close();
                        return true;
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        //Метод добавления в БД нового преподавателя
        public void TeacherAdd(string login, string password, string name)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "insert into teacher (teacher_name, role_id, teacher_home_address, teacher_phone_number, "
                    + "teacher_login, teacher_password) values (@name, 3, ' ', ' ', @login, @password)";
                NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                cmd.Parameters.AddWithValue("login", login);
                cmd.Parameters.AddWithValue("password", Verification.GetSHA512Hash(password));
                cmd.Parameters.AddWithValue("name", name);
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Вы успешно зарегистрированы!");
                }
                else
                {
                    MessageBox.Show("ОШИБКА ЗАПИСИ!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        //Метод редактирования профиля
        public void TeacherUpdateProfil(Teacher teacher)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connect.Open();
                //Запрос на добавление нового преподавателя
                string sqlExp = "update teacher set teacher_name = @Name, teacher_date_of_birth = @DateOfBirth, teacher_phone_number = @PhoneNumber, teacher_home_address ="
                    + " @HomeAddress where teacher_personnel_number = @PersonnelNumber";
                NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                cmd.Parameters.AddWithValue("Name", teacher.TeacherName);
                cmd.Parameters.AddWithValue("DateOfBirth", teacher.TeacherDateOfBirth);
                cmd.Parameters.AddWithValue("PhoneNumber", teacher.TeacherPhoneNumber);
                cmd.Parameters.AddWithValue("HomeAddress", teacher.TeacherHomeAddress);
                cmd.Parameters.AddWithValue("PersonnelNumber", teacher.TeacherPersonnelNumber);
                int i = cmd.ExecuteNonQuery();
                if (i == 1) { MessageBox.Show("Данные обновлены!"); }
                else MessageBox.Show("ОШИБКА ЗАПИСИ!");
            }
            catch (NpgsqlException ex) { MessageBox.Show(ex.Message); return; }
            connect.Close();
        }
        public void TeacherUpdatePassword(Teacher teacher)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "update teacher set password = @Password where teacher_personnel_number = @PersonnelNumber";
                NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                cmd.Parameters.AddWithValue("Password", Verification.GetSHA512Hash(teacher.TeacherPassword));
                cmd.Parameters.AddWithValue("PersonnelNumber", teacher.TeacherPersonnelNumber);
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Пароль обновлён!");
                }
                else
                {
                    MessageBox.Show("ОШИБКА ЗАПИСИ!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        public List<Teacher> LoadTeachers()
        {
            List<Teacher> teachers = new List<Teacher>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select * from teacher, datateacher";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        DateTime dateOfBirth = DateTime.Now;
                        DateTime dateOfIssue = DateTime.Now;
                        if (!(reader[2] is DBNull && reader[12] is DBNull))
                        {
                            dateOfBirth = Convert.ToDateTime(reader[5]);
                            dateOfIssue = Convert.ToDateTime(reader[12]);
                        }
                        teachers.Add(new Teacher((int)reader[0], (int)reader[1], reader[2].ToString(), reader[3].ToString(), reader[4].ToString(), dateOfBirth,
                                    reader[6].ToString(), reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(), reader[11].ToString(),
                                    dateOfIssue));
                    }
                }
                reader.Close();
                return teachers;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return teachers;
            }
            finally
            {
                connection.Close();
            }
        }
        public void TeacherRemove(int id)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "delete from teacher where teacher_personnel_number = @PersonnelNumber";
                NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                cmd.Parameters.AddWithValue("PersonnelNumber", id);
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Пользователь удалён!");
                }
                else
                {
                    MessageBox.Show("ОШИБКА ЗАПИСИ!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        public void TeacherUpdateRole(int RoleId, int PersonnelNumber)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "update teachers set role_id = @RoleId where teacher_personnel_number = @PersonnelNumber";
                NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                cmd.Parameters.AddWithValue("RoleId", RoleId);
                cmd.Parameters.AddWithValue("PersonnelNumber", PersonnelNumber);
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Роль обновлена!");
                }
                else
                {
                    MessageBox.Show("ОШИБКА ЗАПИСИ!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
    }
}