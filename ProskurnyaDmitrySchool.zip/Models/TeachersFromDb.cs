﻿using Npgsql;
using ProskurnyaDmitrySchool.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Models
{
    internal class TeachersFromDb
    {
        public Teacher GetTeacher(string login, string password)
        {
            Teacher teacher = null;
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();
                    string sqlExp = "select * from teacher where teacher_login = @login";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("login", login);
                    NpgsqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        if (password != "")
                        {
                            if (Verification.VerifySHA512Hash(password, (string)reader["TeacherPassword"]))
                            {
                                teacher = new Teacher((int)reader[0], reader[1].ToString(), Convert.ToDateTime(reader[2]), reader[3].ToString(), reader[4].ToString(), (int)reader[5], reader[6].ToString(), reader[7].ToString());
                            }
                            else
                            {
                                MessageBox.Show("Неверный пароль!");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Нет такого пользователя!");
                    }
                    return teacher;
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return teacher;
            }
        }
        public bool CheckPassword(string password, string passRepeat)
        {
            if (password.Length < 6)
            {
                MessageBox.Show("Длина пароля не может быть меньше 6 символов!");
                return false;
            }
            else
            {
                bool f, f1, f2;
                f = f1 = f2 = false;
                for (int i = 0; i < password.Length; i++)
                {
                    if (Char.IsDigit(password[i]))
                    {
                        f1 = true;
                    }
                    if (Char.IsUpper(password[i]))
                    {
                        f2 = true;
                    }
                    if (f1 && f2)
                    {
                        break;
                    }
                }

                if (!(f1 && f2))
                {
                    MessageBox.Show("Пароль должен содержать хотя бы одну цифру и одну заглавную букву!");
                    return f1 && f2;
                }
                else
                {
                    string simbol = "!@#$%^";
                    for (int i = 0; i < password.Length; i++)
                    {
                        for (int j = 0; j < simbol.Length; j++)
                        {
                            if (password[i] == simbol[j])
                            {
                                f = true;
                                break;
                            }
                        }
                    }
                    if (!f)
                    {
                        MessageBox.Show("Пароль должен содержать один из символов '!@#$%^'!");
                    }
                    if ((password == passRepeat) && f)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Неверно потверждён пароль!");
                        return false;
                    }
                }
            }
        }
        public bool CheckUser(string login)
        {
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr))
                {
                    connect.Open();
                    string sqlExp = "SELECT login FROM Users WHERE login=@login";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("@login", login);
                    NpgsqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        MessageBox.Show("Такой логин уже есть!");
                        return false;
                    }
                    else
                    {
                        reader.Close();
                        return true;
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        public void UserAdd(string login, string password, string firstName, string lastName)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "INSERT INTO public.Users (firstname, lastname, patronymic, login, password, adress, role_id, phone) "
                    + "VALUES (@FirstName, @LastName, ' ', @login, @password, ' ', 3, ' ')";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("login", login);
                cmd1.Parameters.AddWithValue("password", Verification.GetSHA512Hash(password));
                cmd1.Parameters.AddWithValue("FirstName", firstName);
                cmd1.Parameters.AddWithValue("LastName", lastName);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Вы успешно зарегистрированы!");
                }
                else
                {
                    MessageBox.Show("Ошибка записи!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
    }
}