﻿using Npgsql;
using ProskurnyaDmitrySchool.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Models
{
    internal class TopicsFromDb
    {
        //Метод загрузки всех данных из таблицы Темы, возвращает список объектов типа Темы
        public List<Topic> LoadTopics()
        {
            List<Topic> topics = new List<Topic>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select topic_name, subject_name, hours_to_study, type from topic, subject where topic.subject_code = "
                    + "subject.subject_code";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        //Добавляю полученную строку в список, путём создания нового экземпляра класса Ученики
                        topics.Add(new Topic((int)reader[0], reader[1].ToString(), (int)reader[2], reader[3].ToString()));
                    }
                }
                reader.Close();
                return topics;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return topics;
            }
            finally
            {
                connection.Close();
            }
        }
        //Метод добавления темы
        public void TopicAdd(int subject, int hours, string name)
        {
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            connection.Open();
            NpgsqlTransaction transaction = connection.BeginTransaction();
            NpgsqlCommand cmd = connection.CreateCommand();
            cmd.Transaction = transaction;
            try
            {
                cmd.CommandText = "insert into topic (subject_code, hours_to_study, type) values (@SubjectCode, @HoursToStudy, @Type)";
                cmd.Parameters.AddWithValue("@SubjectCode", subject);
                cmd.Parameters.AddWithValue("@HoursToStudy", hours);
                cmd.Parameters.AddWithValue("@Type", name);
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Тема добавлена!");
                }
                else
                {
                    MessageBox.Show("ОШИБКА ЗАПИСИ!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        //Метод удаления темы
        public void TopicRemove(int topicName)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "delete from topic where topic_name = @topicName";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("topicName", topicName);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Тема удалена!");
                }
                else
                {
                    MessageBox.Show("ОШИБКА ЗАПИСИ!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
    }
}
