﻿using Npgsql;
using ProskurnyaDmitrySchool.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaDmitrySchool.Models
{
    internal class TopicsFromDb
    {
        //Метод загрузки всех данных из таблицы Темы, возвращает список объектов типа Темы
        public List<Topic> LoadTopics()
        {
            List<Topic> topics = new List<Topic>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select topic_name, subject_name, hours_to_study, type from topic, subject where topic.subject_code = "
                    + "subject.subject_code";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        //Добавляю полученную строку в список, путём создания нового экземпляра класса Ученики
                        topics.Add(new Topic((int)reader[0], reader[1].ToString(), (int)reader[2], reader[3].ToString()));
                    }
                }
                reader.Close();
                return topics;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return topics;
            }
            finally
            {
                connection.Close();
            }
        }
        //Метод удаления темы
        public void TopicRemove(int topicName)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "delete from topic where topic_name = @topicName";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("topicName", topicName);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("ОШИБКА ЗАПИСИ!");
                }
                else
                {
                    MessageBox.Show("Тема удалена!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
    }
}
