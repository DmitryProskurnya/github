﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProskurnyaEquestrianCompetitions.Classes
{
    public class Employee
    {

        public int Employee_Id { get; set; }
        public string Employee_Name { get; set; }
        public int Employee_Role { get; set; }
        public string Employee_Login { get; set; }
        public string Employee_Password { get; set; }
        public Employee(int employee_Id, string employee_Name, int employee_Role, string employee_Login, string employee_Password)
        {
            Employee_Id = employee_Id;
            Employee_Name = employee_Name;
            Employee_Role = employee_Role;
            Employee_Login = employee_Login;
            Employee_Password = employee_Password;
        }
    }
}
