﻿namespace ProskurnyaEquestrianCompetitions.Forms
{
    partial class FanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FanForm));
            this.btnMainForm = new System.Windows.Forms.Button();
            this.btnDonate = new System.Windows.Forms.Button();
            this.btnResults = new System.Windows.Forms.Button();
            this.btnParticipants = new System.Windows.Forms.Button();
            this.btnCompetitions = new System.Windows.Forms.Button();
            this.lblHeading = new System.Windows.Forms.Label();
            this.pbx = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbx)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMainForm
            // 
            this.btnMainForm.BackColor = System.Drawing.Color.Gold;
            this.btnMainForm.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnMainForm.ForeColor = System.Drawing.Color.DeepPink;
            this.btnMainForm.Location = new System.Drawing.Point(16, 609);
            this.btnMainForm.Margin = new System.Windows.Forms.Padding(4);
            this.btnMainForm.Name = "btnMainForm";
            this.btnMainForm.Size = new System.Drawing.Size(1013, 66);
            this.btnMainForm.TabIndex = 7;
            this.btnMainForm.Text = "Вернуться на главную форму";
            this.btnMainForm.UseVisualStyleBackColor = false;
            this.btnMainForm.Click += new System.EventHandler(this.btnMainForm_Click);
            // 
            // btnDonate
            // 
            this.btnDonate.BackColor = System.Drawing.Color.Gold;
            this.btnDonate.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDonate.ForeColor = System.Drawing.Color.DeepPink;
            this.btnDonate.Location = new System.Drawing.Point(16, 535);
            this.btnDonate.Margin = new System.Windows.Forms.Padding(4);
            this.btnDonate.Name = "btnDonate";
            this.btnDonate.Size = new System.Drawing.Size(1013, 66);
            this.btnDonate.TabIndex = 10;
            this.btnDonate.Text = "Пожертвовать средства на содержание лошади";
            this.btnDonate.UseVisualStyleBackColor = false;
            this.btnDonate.Click += new System.EventHandler(this.btnDonate_Click);
            // 
            // btnResults
            // 
            this.btnResults.BackColor = System.Drawing.Color.Gold;
            this.btnResults.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnResults.ForeColor = System.Drawing.Color.DeepPink;
            this.btnResults.Location = new System.Drawing.Point(16, 462);
            this.btnResults.Margin = new System.Windows.Forms.Padding(4);
            this.btnResults.Name = "btnResults";
            this.btnResults.Size = new System.Drawing.Size(1013, 66);
            this.btnResults.TabIndex = 9;
            this.btnResults.Text = "Просмотр результатов заезда";
            this.btnResults.UseVisualStyleBackColor = false;
            this.btnResults.Click += new System.EventHandler(this.btnResults_Click);
            // 
            // btnParticipants
            // 
            this.btnParticipants.BackColor = System.Drawing.Color.Gold;
            this.btnParticipants.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnParticipants.ForeColor = System.Drawing.Color.DeepPink;
            this.btnParticipants.Location = new System.Drawing.Point(16, 389);
            this.btnParticipants.Margin = new System.Windows.Forms.Padding(4);
            this.btnParticipants.Name = "btnParticipants";
            this.btnParticipants.Size = new System.Drawing.Size(1013, 66);
            this.btnParticipants.TabIndex = 8;
            this.btnParticipants.Text = "Просмотр информации об участниках заезда";
            this.btnParticipants.UseVisualStyleBackColor = false;
            this.btnParticipants.Click += new System.EventHandler(this.btnParticipants_Click);
            // 
            // btnCompetitions
            // 
            this.btnCompetitions.BackColor = System.Drawing.Color.Gold;
            this.btnCompetitions.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCompetitions.ForeColor = System.Drawing.Color.DeepPink;
            this.btnCompetitions.Location = new System.Drawing.Point(16, 315);
            this.btnCompetitions.Margin = new System.Windows.Forms.Padding(4);
            this.btnCompetitions.Name = "btnCompetitions";
            this.btnCompetitions.Size = new System.Drawing.Size(1013, 66);
            this.btnCompetitions.TabIndex = 11;
            this.btnCompetitions.Text = "Просмотреть информацию о состязаниях и заездах";
            this.btnCompetitions.UseVisualStyleBackColor = false;
            this.btnCompetitions.Click += new System.EventHandler(this.btnCompetitions_Click);
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.BackColor = System.Drawing.Color.Transparent;
            this.lblHeading.Font = new System.Drawing.Font("Calibri", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblHeading.ForeColor = System.Drawing.Color.DeepPink;
            this.lblHeading.Location = new System.Drawing.Point(306, 9);
            this.lblHeading.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(439, 97);
            this.lblHeading.TabIndex = 12;
            this.lblHeading.Text = "Болельщик";
            // 
            // pbx
            // 
            this.pbx.Image = ((System.Drawing.Image)(resources.GetObject("pbx.Image")));
            this.pbx.Location = new System.Drawing.Point(16, 110);
            this.pbx.Margin = new System.Windows.Forms.Padding(4);
            this.pbx.Name = "pbx";
            this.pbx.Size = new System.Drawing.Size(1013, 197);
            this.pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbx.TabIndex = 13;
            this.pbx.TabStop = false;
            // 
            // FanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(1045, 690);
            this.Controls.Add(this.pbx);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.btnCompetitions);
            this.Controls.Add(this.btnDonate);
            this.Controls.Add(this.btnResults);
            this.Controls.Add(this.btnParticipants);
            this.Controls.Add(this.btnMainForm);
            this.Name = "FanForm";
            this.Text = "Болельщик";
            ((System.ComponentModel.ISupportInitialize)(this.pbx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMainForm;
        private System.Windows.Forms.Button btnDonate;
        private System.Windows.Forms.Button btnResults;
        private System.Windows.Forms.Button btnParticipants;
        private System.Windows.Forms.Button btnCompetitions;
        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.PictureBox pbx;
    }
}