﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProskurnyaEquestrianCompetitions.Forms
{
    public partial class FanForm : Form
    {
        public FanForm()
        {
            InitializeComponent();
        }

        private void btnCompetitions_Click(object sender, EventArgs e)
        {
            CompetitionForm competitionForm = new CompetitionForm();
            competitionForm.ShowDialog();
        }

        private void btnParticipants_Click(object sender, EventArgs e)
        {
            ParticipantForm participantForm = new ParticipantForm();
            participantForm.ShowDialog();
        }

        private void btnResults_Click(object sender, EventArgs e)
        {
            ResultForm resultForm = new ResultForm();
            resultForm.ShowDialog();
        }
        private void btnDonate_Click(object sender, EventArgs e)
        {
            DonateForm donateForm = new DonateForm();
            donateForm.ShowDialog();
        }

        private void btnMainForm_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Close();
        }
    }
}
