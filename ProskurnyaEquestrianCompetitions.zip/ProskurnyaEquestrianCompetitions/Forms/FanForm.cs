﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProskurnyaEquestrianCompetitions.Forms
{
    public partial class FanForm : Form
    {
        public FanForm()
        {
            InitializeComponent();
        }

        private void btnCompetitions_Click(object sender, EventArgs e)
        {
            CompetitionsForm competitionsForm = new CompetitionsForm();
            competitionsForm.Show();
            this.Hide();
        }

        private void btnMainForm_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Hide();
        }
    }
}
