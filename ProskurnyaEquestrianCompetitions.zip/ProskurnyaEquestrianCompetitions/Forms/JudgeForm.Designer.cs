﻿namespace ProskurnyaEquestrianCompetitions.Forms
{
    partial class JudgeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeading = new System.Windows.Forms.Label();
            this.btnCompetitions = new System.Windows.Forms.Button();
            this.btnDonate = new System.Windows.Forms.Button();
            this.btnResults = new System.Windows.Forms.Button();
            this.btnParticipants = new System.Windows.Forms.Button();
            this.btnMainForm = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.BackColor = System.Drawing.Color.Transparent;
            this.lblHeading.Font = new System.Drawing.Font("Calibri", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblHeading.ForeColor = System.Drawing.Color.DeepPink;
            this.lblHeading.Location = new System.Drawing.Point(135, 9);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(513, 78);
            this.lblHeading.TabIndex = 12;
            this.lblHeading.Text = "Интерфейс судьи";
            // 
            // btnCompetitions
            // 
            this.btnCompetitions.BackColor = System.Drawing.Color.Gold;
            this.btnCompetitions.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCompetitions.ForeColor = System.Drawing.Color.DeepPink;
            this.btnCompetitions.Location = new System.Drawing.Point(12, 256);
            this.btnCompetitions.Name = "btnCompetitions";
            this.btnCompetitions.Size = new System.Drawing.Size(760, 54);
            this.btnCompetitions.TabIndex = 17;
            this.btnCompetitions.Text = "Ввод и редактирование результатов заезда";
            this.btnCompetitions.UseVisualStyleBackColor = false;
            // 
            // btnDonate
            // 
            this.btnDonate.BackColor = System.Drawing.Color.Gold;
            this.btnDonate.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDonate.ForeColor = System.Drawing.Color.DeepPink;
            this.btnDonate.Location = new System.Drawing.Point(12, 435);
            this.btnDonate.Name = "btnDonate";
            this.btnDonate.Size = new System.Drawing.Size(760, 54);
            this.btnDonate.TabIndex = 16;
            this.btnDonate.Text = "Отчет о результатах состязания";
            this.btnDonate.UseVisualStyleBackColor = false;
            // 
            // btnResults
            // 
            this.btnResults.BackColor = System.Drawing.Color.Gold;
            this.btnResults.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnResults.ForeColor = System.Drawing.Color.DeepPink;
            this.btnResults.Location = new System.Drawing.Point(12, 375);
            this.btnResults.Name = "btnResults";
            this.btnResults.Size = new System.Drawing.Size(760, 54);
            this.btnResults.TabIndex = 15;
            this.btnResults.Text = "Просмотр результатов заезда";
            this.btnResults.UseVisualStyleBackColor = false;
            // 
            // btnParticipants
            // 
            this.btnParticipants.BackColor = System.Drawing.Color.Gold;
            this.btnParticipants.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnParticipants.ForeColor = System.Drawing.Color.DeepPink;
            this.btnParticipants.Location = new System.Drawing.Point(12, 316);
            this.btnParticipants.Name = "btnParticipants";
            this.btnParticipants.Size = new System.Drawing.Size(760, 54);
            this.btnParticipants.TabIndex = 14;
            this.btnParticipants.Text = "Ввод информации о нарушениях участников";
            this.btnParticipants.UseVisualStyleBackColor = false;
            // 
            // btnMainForm
            // 
            this.btnMainForm.BackColor = System.Drawing.Color.Gold;
            this.btnMainForm.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnMainForm.ForeColor = System.Drawing.Color.DeepPink;
            this.btnMainForm.Location = new System.Drawing.Point(12, 495);
            this.btnMainForm.Name = "btnMainForm";
            this.btnMainForm.Size = new System.Drawing.Size(760, 54);
            this.btnMainForm.TabIndex = 13;
            this.btnMainForm.Text = "Вернуться на главную форму";
            this.btnMainForm.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gold;
            this.button1.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.DeepPink;
            this.button1.Location = new System.Drawing.Point(12, 136);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(760, 54);
            this.button1.TabIndex = 19;
            this.button1.Text = "Назначение дорожки для каждого участника заезда";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gold;
            this.button2.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.Color.DeepPink;
            this.button2.Location = new System.Drawing.Point(12, 196);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(760, 54);
            this.button2.TabIndex = 18;
            this.button2.Text = "Просмотр информации об участниках заезда";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // JudgeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnCompetitions);
            this.Controls.Add(this.btnDonate);
            this.Controls.Add(this.btnResults);
            this.Controls.Add(this.btnParticipants);
            this.Controls.Add(this.btnMainForm);
            this.Controls.Add(this.lblHeading);
            this.Name = "JudgeForm";
            this.Text = "Судья";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.Button btnCompetitions;
        private System.Windows.Forms.Button btnDonate;
        private System.Windows.Forms.Button btnResults;
        private System.Windows.Forms.Button btnParticipants;
        private System.Windows.Forms.Button btnMainForm;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}