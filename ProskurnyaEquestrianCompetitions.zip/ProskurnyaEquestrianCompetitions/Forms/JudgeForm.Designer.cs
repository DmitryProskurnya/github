﻿namespace ProskurnyaEquestrianCompetitions.Forms
{
    partial class JudgeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeading = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnResults = new System.Windows.Forms.Button();
            this.btnViolation = new System.Windows.Forms.Button();
            this.btnMainForm = new System.Windows.Forms.Button();
            this.btnTrack = new System.Windows.Forms.Button();
            this.btnParticipants = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.BackColor = System.Drawing.Color.Transparent;
            this.lblHeading.Font = new System.Drawing.Font("Calibri", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblHeading.ForeColor = System.Drawing.Color.DeepPink;
            this.lblHeading.Location = new System.Drawing.Point(135, 9);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(513, 78);
            this.lblHeading.TabIndex = 12;
            this.lblHeading.Text = "Интерфейс судьи";
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.Gold;
            this.btnEdit.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnEdit.ForeColor = System.Drawing.Color.DeepPink;
            this.btnEdit.Location = new System.Drawing.Point(12, 256);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(760, 54);
            this.btnEdit.TabIndex = 17;
            this.btnEdit.Text = "Ввод и редактирование результатов заезда";
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnReport
            // 
            this.btnReport.BackColor = System.Drawing.Color.Gold;
            this.btnReport.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnReport.ForeColor = System.Drawing.Color.DeepPink;
            this.btnReport.Location = new System.Drawing.Point(12, 435);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(760, 54);
            this.btnReport.TabIndex = 16;
            this.btnReport.Text = "Отчет о результатах состязания";
            this.btnReport.UseVisualStyleBackColor = false;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // btnResults
            // 
            this.btnResults.BackColor = System.Drawing.Color.Gold;
            this.btnResults.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnResults.ForeColor = System.Drawing.Color.DeepPink;
            this.btnResults.Location = new System.Drawing.Point(12, 375);
            this.btnResults.Name = "btnResults";
            this.btnResults.Size = new System.Drawing.Size(760, 54);
            this.btnResults.TabIndex = 15;
            this.btnResults.Text = "Просмотр результатов заезда";
            this.btnResults.UseVisualStyleBackColor = false;
            this.btnResults.Click += new System.EventHandler(this.btnResults_Click);
            // 
            // btnViolation
            // 
            this.btnViolation.BackColor = System.Drawing.Color.Gold;
            this.btnViolation.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnViolation.ForeColor = System.Drawing.Color.DeepPink;
            this.btnViolation.Location = new System.Drawing.Point(12, 316);
            this.btnViolation.Name = "btnViolation";
            this.btnViolation.Size = new System.Drawing.Size(760, 54);
            this.btnViolation.TabIndex = 14;
            this.btnViolation.Text = "Ввод информации о нарушениях участников";
            this.btnViolation.UseVisualStyleBackColor = false;
            this.btnViolation.Click += new System.EventHandler(this.btnViolation_Click);
            // 
            // btnMainForm
            // 
            this.btnMainForm.BackColor = System.Drawing.Color.Gold;
            this.btnMainForm.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnMainForm.ForeColor = System.Drawing.Color.DeepPink;
            this.btnMainForm.Location = new System.Drawing.Point(12, 495);
            this.btnMainForm.Name = "btnMainForm";
            this.btnMainForm.Size = new System.Drawing.Size(760, 54);
            this.btnMainForm.TabIndex = 13;
            this.btnMainForm.Text = "Вернуться на главную форму";
            this.btnMainForm.UseVisualStyleBackColor = false;
            this.btnMainForm.Click += new System.EventHandler(this.btnMainForm_Click);
            // 
            // btnTrack
            // 
            this.btnTrack.BackColor = System.Drawing.Color.Gold;
            this.btnTrack.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnTrack.ForeColor = System.Drawing.Color.DeepPink;
            this.btnTrack.Location = new System.Drawing.Point(12, 136);
            this.btnTrack.Name = "btnTrack";
            this.btnTrack.Size = new System.Drawing.Size(760, 54);
            this.btnTrack.TabIndex = 19;
            this.btnTrack.Text = "Назначение дорожки для каждого участника заезда";
            this.btnTrack.UseVisualStyleBackColor = false;
            this.btnTrack.Click += new System.EventHandler(this.btnTrack_Click);
            // 
            // btnParticipants
            // 
            this.btnParticipants.BackColor = System.Drawing.Color.Gold;
            this.btnParticipants.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnParticipants.ForeColor = System.Drawing.Color.DeepPink;
            this.btnParticipants.Location = new System.Drawing.Point(12, 196);
            this.btnParticipants.Name = "btnParticipants";
            this.btnParticipants.Size = new System.Drawing.Size(760, 54);
            this.btnParticipants.TabIndex = 18;
            this.btnParticipants.Text = "Просмотр информации об участниках заезда";
            this.btnParticipants.UseVisualStyleBackColor = false;
            this.btnParticipants.Click += new System.EventHandler(this.btnParticipants_Click);
            // 
            // JudgeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.btnTrack);
            this.Controls.Add(this.btnParticipants);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.btnResults);
            this.Controls.Add(this.btnViolation);
            this.Controls.Add(this.btnMainForm);
            this.Controls.Add(this.lblHeading);
            this.Name = "JudgeForm";
            this.Text = "Судья";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Button btnResults;
        private System.Windows.Forms.Button btnViolation;
        private System.Windows.Forms.Button btnMainForm;
        private System.Windows.Forms.Button btnTrack;
        private System.Windows.Forms.Button btnParticipants;
    }
}