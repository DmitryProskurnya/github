﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProskurnyaEquestrianCompetitions.Forms
{
    public partial class JudgeForm : Form
    {
        public JudgeForm()
        {
            InitializeComponent();
        }

        private void btnTrack_Click(object sender, EventArgs e)
        {
            TrackForm trackForm = new TrackForm();
            trackForm.ShowDialog();
        }

        private void btnParticipants_Click(object sender, EventArgs e)
        {
            ParticipantForm participantForm = new ParticipantForm();
            participantForm.ShowDialog();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            EditForm editform = new EditForm();
            editform.ShowDialog();
        }

        private void btnViolation_Click(object sender, EventArgs e)
        {
            ViolationForm violationform = new ViolationForm();
            violationform.ShowDialog();
        }

        private void btnResults_Click(object sender, EventArgs e)
        {
            ResultForm resultform = new ResultForm();
            resultform.ShowDialog();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            ReportForm reportForm = new ReportForm();
            reportForm.ShowDialog();
        }

        private void btnMainForm_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Hide();
        }
    }
}
