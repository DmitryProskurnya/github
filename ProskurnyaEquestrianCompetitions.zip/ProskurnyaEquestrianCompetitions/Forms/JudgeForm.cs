﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProskurnyaEquestrianCompetitions.Forms
{
    public partial class JudgeForm : Form
    {
        public JudgeForm()
        {
            InitializeComponent();
        }

        private void btnTrack_Click(object sender, EventArgs e)
        {
            TrackForm trackForm = new TrackForm();
            trackForm.Show();
            this.Hide();
        }

        private void btnParticipants_Click(object sender, EventArgs e)
        {
            ParticipantForm participantForm = new ParticipantForm();
            participantForm.Show();
            this.Hide();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            EditForm editform = new EditForm();
            editform.Show();
            this.Hide();
        }

        private void btnViolation_Click(object sender, EventArgs e)
        {
            ViolationForm violationform = new ViolationForm();
            violationform.Show();
            this.Hide();
        }

        private void btnResults_Click(object sender, EventArgs e)
        {
            ResultForm resultform = new ResultForm();
            resultform.Show();
            this.Hide();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            ReportForm reportForm = new ReportForm();
            reportForm.Show();
            this.Hide();
        }

        private void btnMainForm_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Hide();
        }
    }
}
