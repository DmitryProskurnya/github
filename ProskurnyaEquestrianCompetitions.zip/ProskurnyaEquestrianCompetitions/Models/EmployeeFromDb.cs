﻿using Npgsql;
using ProskurnyaEquestrianCompetitions.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProskurnyaEquestrianCompetitions.Models
{
    internal class EmployeeFromDb
    {
        public Employee GetEmployee(string login, string password)
        {
            Employee employee = null;
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();
                    string sqlExp = "select employee_id, employee_name, employee_role, employee_login, employee_password from employee where employee_login "
                        + "= @login";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("login", login);
                    NpgsqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        if (password != "")
                        {
                            if (Verification.VerifySHA512Hash(password, (string)reader["employee_password"]))
                            {
                                employee = new Employee((int)reader[0], reader[1].ToString(), (int)reader[2], reader[3].ToString(), reader[4].ToString());
                            }
                            else
                            {
                                MessageBox.Show("ОШИБКА: Неверный пароль!");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("ОШИБКА: Нет такого пользователя!");
                    }
                    return employee;
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return employee;
            }
        }
    }
}
