package com.example.proskurnyalab14.domain.adapters;
import android.content.Context;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.proskurnyalab14.data.db.ShoplistItemEntity;
import com.example.proskurnyalab14.databinding.ShoplistItemBinding;

import java.util.ArrayList;
public class ShoplistAdapter extends RecyclerView.Adapter<ShoplistAdapter.ViewHolder> {
    private ArrayList<ShoplistItemEntity> shoplistItems;
    private final OnShopListItemClick onShopListItemClick;
    private final Context context;
    private final OnMenuItemSelected onMenuItemSelected;
    public interface OnShopListItemClick {
        void onItemClicked(int position, boolean checked);
    }
    public interface OnMenuItemSelected {
        void onShopListMenuItemSelected(int position, MenuItem item);
    }
    public ShoplistAdapter(Context context, ArrayList<ShoplistItemEntity> shoplistItems, OnShopListItemClick onItemClick, OnMenuItemSelected onMenuItemSelected) {
        this.context = context;
        this.shoplistItems = shoplistItems;
        this.onShopListItemClick = onItemClick;
        this.onMenuItemSelected = onMenuItemSelected;
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        public ShoplistItemBinding binding;
        public ViewHolder(@NonNull ShoplistItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            binding.checkbox.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    boolean isChecked = binding.checkbox.isChecked();
                    onShopListItemClick.onItemClicked(position, isChecked);
                }
            });
        }
}