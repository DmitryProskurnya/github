package com.example.proskurnyalab14.domain.adapters;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.proskurnyalab14.R;
import com.example.proskurnyalab14.databinding.ShoplistItemBinding;
public class ViewHolder extends RecyclerView.ViewHolder {
    public ShoplistItemBinding binding;
    public ViewHolder(@NonNull ShoplistItemBinding binding) {
        super(binding.getRoot());
        this.binding = binding;
        binding.productChecked.setOnClickListener(v -> {
            int position = getAdapterPosition();
            if (position != RecyclerView.NO_POSITION) {
                boolean isChecked = binding.productChecked.isChecked();
                onShopListItemClick.onItemClicked(position, isChecked);
            }
        });
    }
    @NonNull
    @Override
    public ShopListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ShoplistItemBinding binding = ShoplistItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }
    @Override
    public void onBindViewHolder(@NonNull ShoplistAdapter.ViewHolder holder, int position) {
        holder.binding.productName.setText(shoplistItems.get(position).getName());
        holder.binding.productChecked.setChecked(shoplistItems.get(position).isCompleted());
        holder.binding.getRoot().setOnLongClickListener(view -> {
            PopupMenu menu = new PopupMenu(context, view);
            menu.inflate(R.menu.list_menu);
            menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                    onMenuItemSelected.onShopListMenuItemSelected(position, menuItem);
                    return true;
                }
            });
            menu.show();
            return true;
        });
    }
    @Override
    public int getItemCount() {
        return shoplistItems.size();
    }
}