package com.example.proskurnyalab14.ui.fragments;
import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;
import com.example.proskurnyalab14.data.db.ShoplistItemEntity;
import com.example.proskurnyalab14.domain.viewmodels.ShoplistViewModel;
public class NewRecordDialog extends DialogFragment {
    NewRecordDialogBinding binding;
    ShoplistViewModel viewModel;
    ShoplistItemEntity entity;
    public static String TAG = "NewRecordDialog";
    public NewRecordDialog(ShoplistItemEntity entityToEdit) { entity = entityToEdit; }
    @Override
    public void onCreate(@NonNull Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = new ViewModelProvider(this).get(ShoplistViewModel.class);
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        binding = NewRecordDialogBinding.inflate(getLayoutInflater());
        String positiveButtonText = "Добавить";
        String dialogTitle = "Новая запись";
        if (entity != null) {
            binding.NewRecordText.setText(entity.getName());
            dialogTitle = "Редактирование";
            positiveButtonText = "Изменить";
        }
        return new AlertDialog.Builder(requireContext())
                .setTitle(dialogTitle)
                .setView(binding.getRoot())
                .setPositiveButton(positiveButtonText, (dialog, which) -> {
                    if (entity != null) {
                        entity.setName(binding.NewRecordText.getText().toString());
                        viewModel.updateItems(entity);
                    }
                    else {
                        ShoplistItemEntity entity = new ShoplistItemEntity(0, binding.NewRecordText.getText().toString(), false);
                        viewModel.insertItems(entity);
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("Отмена", (dialog, which) -> {
                    dialog.dismiss();
                })
                .show();
    }
}