package com.example.proskurnyalab14.ui.fragments;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.example.proskurnyalab14.R;
import com.example.proskurnyalab14.data.db.ShoplistItemEntity;
import com.example.proskurnyalab14.databinding.FragmentShoplistBinding;
import com.example.proskurnyalab14.domain.adapters.ShoplistAdapter;
import com.example.proskurnyalab14.domain.viewmodels.ShoplistViewModel;
import java.util.ArrayList;
public class ShopListFragment extends Fragment {
    FragmentShoplistBinding binding;
    ShoplistAdapter adapter;
    public static ShopListFragment newInstance() { return new ShopListFragment(); }
    ShoplistViewModel viewModel;
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentShoplistBinding.inflate(inflater);
        viewModel = new ViewModelProvider(this).get(ShoplistViewModel.class);
        ShoplistAdapter.OnShopListItemClick onItemClick = (position, checked) -> {
            ShoplistItemEntity item = adapter.getElementByPosition(position);
            item.setCompleted(checked);
            viewModel.updateItems(item);
        };
        ShoplistAdapter.OnMenuItemSelected onMenuItemSelected = (position, item) -> {
            if (item.getItemId() == R.id.deleteItem) {
                ShoplistItemEntity entity = adapter.getElementByPosition(position);
                viewModel.deleteItems(entity);
            }
            else if (item.getItemId() == R.id.redactItem) {
                ShoplistItemEntity entity = adapter.getElementByPosition(position);
                new NewRecordDialog(entity).show(getChildFragmentManager(), NewRecordDialog.TAG);
            }
        };
        ArrayList<ShoplistItemEntity> items = (ArrayList<ShoplistItemEntity>) viewModel.shopListItems.getValue();
        if (items == null) {
            items = new ArrayList<>();
        }
        adapter = new ShoplistAdapter(requireContext(), items, onItemClick, onMenuItemSelected);
        viewModel.shopListItems.observe(getViewLifecycleOwner(), shoplistItemEntities -> adapter.updateData((ArrayList<ShoplistItemEntity>) shoplistItemEntities));
        binding.shoplistView.setAdapter(adapter);
        binding.addItemButton.setOnClickListener(v -> {
            new NewRecordDialog(null).show(getChildFragmentManager(), NewRecordDialog.TAG);
        });
        return binding.getRoot();
    }
}