package com.example.proskurnyalab15;

public class jokeClass {
    public int id;
    public String type;
    public String setup;
    public String punchline;
    public jokeClass(int id, String type, String setup, String punchline) {
        this.id = id;
        this.type = type;
        this.setup = setup;
        this.punchline = punchline;
    }
}