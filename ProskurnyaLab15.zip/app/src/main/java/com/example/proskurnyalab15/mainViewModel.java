package com.example.proskurnyalab15;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
public class mainViewModel extends ViewModel {
    private MutableLiveData<jokeClass> _joke = new MutableLiveData<>(new jokeClass(0, "Пусто", "Здесь будет шутка: ", "ГДЕ ШУТКА?"));
    public LiveData<jokeClass> joke() { return _joke; }
    private jokesInterface api = new Retrofit.Builder().baseUrl("https://official-joke-api.appspot.com")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(jokesInterface.class);
    public mainViewModel() {
        postNewJoke();
    }
    public void postNewJoke() {
        api.getRandomJoke().enqueue(new Callback<List<jokeClass>>() {
            @Override
            public void onResponse(Call<List<jokeClass>> call, Response<List<jokeClass>> response) {
                if(response.isSuccessful()) {
                    _joke.postValue(response.body().get(0));
                }
            }
            @Override
            public void onFailure(Call<List<jokeClass>> call, Throwable t) {
                _joke.postValue(new jokeClass(0, "Error", "Произошла ошибка: ", t.getLocalizedMessage()));
            }
        });
    }
}