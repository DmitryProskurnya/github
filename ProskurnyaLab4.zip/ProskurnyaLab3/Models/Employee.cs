﻿using System;
using System.Collections.Generic;

namespace ProskurnyaLab3.Models;

public partial class Employee
{
    public int Id { get; set; }

    public string Surname { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Patronymic { get; set; } = null!;

    public string Tekephone { get; set; } = null!;

    public string Email { get; set; } = null!;

    public DateOnly BirthDate { get; set; }

    public int TitleId { get; set; }

    public virtual Title Title { get; set; } = null!;
}
