﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProskurnyaLab3.Models
{
    class ListTitle : ObservableCollection<Title>
    {
        public ListTitle()
        {
            var queryTitle = from title in PageEmployee.dbContext.Titles select title;
            foreach (var item in queryTitle)
            {
                this.Add(item);
            }
        }
    }
}
