﻿using System;
using System.Collections.Generic;

namespace ProskurnyaLab3.Models;

public partial class Employee
{
    static Employee emp;
    public static Employee CreateEmployee(string name, string surname, string patronymic, string tekephone, string email, int id)
    {
        emp = new Employee();
        emp.Name = name;
        emp.Surname = surname;
        emp.Patronymic = patronymic;
        emp.Tekephone = tekephone;
        emp.Email = email;
        emp.Id = id;
        return emp;
    }
    public int Id { get; set; }

    public string Surname { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Patronymic { get; set; } = null!;

    public string Tekephone { get; set; } = null!;

    public string Email { get; set; } = null!;

    DateTime birthDate;
    public DateTime BirthDate
    {
        get { return birthDate; }
        set
        {
            birthDate = value;
            birthDate = DateTime.SpecifyKind(birthDate, DateTimeKind.Utc);
        }
    }

    public int TitleId { get; set; }

    public virtual Title Title { get; set; } = null!;
}
