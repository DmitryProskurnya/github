package com.example.proskurnyalabkulinary;
import android.app.Application;
public class FoodApplication extends Application {
    private static FoodApplication Instance;
    @Override
    public void onCreate() {
        super.onCreate();
        Instance = this;
    }
    public static FoodApplication getInstance() { return Instance; }
}