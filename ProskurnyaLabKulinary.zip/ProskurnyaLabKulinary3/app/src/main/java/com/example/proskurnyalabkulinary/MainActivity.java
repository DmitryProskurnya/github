package com.example.proskurnyalabkulinary;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.window.SplashScreen;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SplashScreen splashScreen = SplashScreen.installSplashScreen(this);
        super.onCreate(savedInstanceState);
    }
}