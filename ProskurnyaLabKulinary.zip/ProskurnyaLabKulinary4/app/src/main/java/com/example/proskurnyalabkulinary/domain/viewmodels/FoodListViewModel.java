package com.example.proskurnyalabkulinary.domain.viewmodels;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.proskurnyalabkulinary.FoodApplication;
import com.example.proskurnyalabkulinary.data.db.FoodDao;
import com.example.proskurnyalabkulinary.data.db.FoodEntity;
import java.util.List;
public class FoodListViewModel extends ViewModel {
    private final FoodDao foodDao = FoodApplication.getInstance().getDB().getFoodDao();
    public LiveData<List<FoodEntity>> foodList = foodDao.getAllFood();
}