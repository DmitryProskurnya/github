package com.example.proskurnyalabkulinary.ui.fragments;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.proskurnyalabkulinary.R;
import com.example.proskurnyalabkulinary.data.db.FoodEntity;
import com.example.proskurnyalabkulinary.databinding.FragmentMainBinding;
import com.example.proskurnyalabkulinary.domain.adapters.FoodListAdapter;
import com.example.proskurnyalabkulinary.domain.viewmodels.FoodListViewModel;

import java.util.ArrayList;

public class MainFragment extends Fragment {
    FragmentMainBinding binding;
    FoodListViewModel viewModel;
    public MainFragment() {}
    public static MainFragment newInstance() { return new MainFragment(); }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = new ViewModelProvider(this).get(FoodListViewModel.class);
    }
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentMainBinding.inflate(inflater);
        ArrayList<FoodEntity> foodList = (ArrayList<FoodEntity>) viewModel.foodList.getValue();
        if(foodList == null) {
            foodList = new ArrayList<>();
        }
        FoodListAdapter adapter = new FoodListAdapter(foodList);
        viewModel.foodList.observe(getViewLifecycleOwner(), foodEntities -> {
            adapter.updateData((ArrayList<FoodEntity>) foodEntities);
        });
        binding.foodListView.setAdapter(adapter);
        binding.addFoodButton.setOnClickListener(v -> {
            Navigation.findNavController(binding.getRoot()).navigate(R.id.action_mainFragment_to_addFoodFragment);
        });
        return binding.getRoot();
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}