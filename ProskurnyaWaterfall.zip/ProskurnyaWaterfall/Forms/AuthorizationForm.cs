﻿using ProskurnyaWaterfall.Classes;
using ProskurnyaWaterfall.Models;
using System;
using System.Windows.Forms;
namespace ProskurnyaWaterfall.Forms
{
    public partial class AuthorizationForm : Form
    {
        EmployeesFromDb employeesFromDb = new EmployeesFromDb();
        public static Employee currentEmployee { get; set; } = null;
        public AuthorizationForm()
        {
            InitializeComponent();
        }
        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (tbxLogin.Text == "" || tbxPassword.Text == "")
            {
                MessageBox.Show("ОШИБКА: Не во всех полях введены данные!");
                return;
            }
            else
            {
                currentEmployee = employeesFromDb.GetEmployee(tbxLogin.Text, tbxPassword.Text);
                if (currentEmployee != null)
                {
                    СashierForm cashierForm = new СashierForm();
                    cashierForm.Show();
                    this.Hide();
                }
                /*else
                {
                    ControllerForm controllerForm = new ControllerForm();
                    controllerForm.Show();
                    this.Hide();
                }*/
                
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}