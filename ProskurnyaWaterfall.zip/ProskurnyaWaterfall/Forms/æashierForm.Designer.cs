﻿namespace ProskurnyaWaterfall
{
    partial class СashierForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.cbxName = new System.Windows.Forms.ComboBox();
            this.cbxTime = new System.Windows.Forms.ComboBox();
            this.lbl3 = new System.Windows.Forms.Label();
            this.cbxCategory = new System.Windows.Forms.ComboBox();
            this.lbl4 = new System.Windows.Forms.Label();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.lbl5 = new System.Windows.Forms.Label();
            this.btnAddTicket = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCreateQRCode = new System.Windows.Forms.Button();
            this.imgQRCode = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgQRCode)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Bahnschrift", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbl1.ForeColor = System.Drawing.Color.Green;
            this.lbl1.Location = new System.Drawing.Point(20, 20);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(537, 58);
            this.lbl1.TabIndex = 11;
            this.lbl1.Text = "ДОБАВЛЕНИЕ БИЛЕТА";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbl2.ForeColor = System.Drawing.Color.Black;
            this.lbl2.Location = new System.Drawing.Point(130, 103);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(64, 29);
            this.lbl2.TabIndex = 12;
            this.lbl2.Text = "ФИО";
            // 
            // cbxName
            // 
            this.cbxName.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbxName.ForeColor = System.Drawing.Color.Black;
            this.cbxName.FormattingEnabled = true;
            this.cbxName.Location = new System.Drawing.Point(200, 100);
            this.cbxName.Name = "cbxName";
            this.cbxName.Size = new System.Drawing.Size(300, 37);
            this.cbxName.TabIndex = 13;
            // 
            // cbxTime
            // 
            this.cbxTime.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbxTime.ForeColor = System.Drawing.Color.Black;
            this.cbxTime.FormattingEnabled = true;
            this.cbxTime.Location = new System.Drawing.Point(200, 150);
            this.cbxTime.Name = "cbxTime";
            this.cbxTime.Size = new System.Drawing.Size(300, 37);
            this.cbxTime.TabIndex = 15;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbl3.ForeColor = System.Drawing.Color.Black;
            this.lbl3.Location = new System.Drawing.Point(103, 153);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(91, 29);
            this.lbl3.TabIndex = 14;
            this.lbl3.Text = "ВРЕМЯ";
            // 
            // cbxCategory
            // 
            this.cbxCategory.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbxCategory.ForeColor = System.Drawing.Color.Black;
            this.cbxCategory.FormattingEnabled = true;
            this.cbxCategory.Location = new System.Drawing.Point(200, 200);
            this.cbxCategory.Name = "cbxCategory";
            this.cbxCategory.Size = new System.Drawing.Size(300, 37);
            this.cbxCategory.TabIndex = 17;
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbl4.ForeColor = System.Drawing.Color.Black;
            this.lbl4.Location = new System.Drawing.Point(50, 203);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(144, 29);
            this.lbl4.TabIndex = 16;
            this.lbl4.Text = "КАТЕГОРИЯ";
            // 
            // dtpDate
            // 
            this.dtpDate.CalendarFont = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dtpDate.CalendarForeColor = System.Drawing.Color.Black;
            this.dtpDate.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.dtpDate.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dtpDate.Location = new System.Drawing.Point(200, 250);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(300, 36);
            this.dtpDate.TabIndex = 18;
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbl5.ForeColor = System.Drawing.Color.Black;
            this.lbl5.Location = new System.Drawing.Point(120, 253);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(74, 29);
            this.lbl5.TabIndex = 19;
            this.lbl5.Text = "ДАТА";
            // 
            // btnAddTicket
            // 
            this.btnAddTicket.BackColor = System.Drawing.Color.LightGreen;
            this.btnAddTicket.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAddTicket.ForeColor = System.Drawing.Color.Green;
            this.btnAddTicket.Location = new System.Drawing.Point(300, 300);
            this.btnAddTicket.Name = "btnAddTicket";
            this.btnAddTicket.Size = new System.Drawing.Size(250, 50);
            this.btnAddTicket.TabIndex = 20;
            this.btnAddTicket.Text = "ДОБАВИТЬ БИЛЕТ";
            this.btnAddTicket.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.LightCoral;
            this.btnExit.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnExit.ForeColor = System.Drawing.Color.Red;
            this.btnExit.Location = new System.Drawing.Point(400, 480);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(150, 50);
            this.btnExit.TabIndex = 21;
            this.btnExit.Text = "ВЫЙТИ";
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // btnCreateQRCode
            // 
            this.btnCreateQRCode.BackColor = System.Drawing.Color.LightGreen;
            this.btnCreateQRCode.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCreateQRCode.ForeColor = System.Drawing.Color.Green;
            this.btnCreateQRCode.Location = new System.Drawing.Point(20, 300);
            this.btnCreateQRCode.Name = "btnCreateQRCode";
            this.btnCreateQRCode.Size = new System.Drawing.Size(250, 50);
            this.btnCreateQRCode.TabIndex = 22;
            this.btnCreateQRCode.Text = "СОЗДАТЬ QR-КОД";
            this.btnCreateQRCode.UseVisualStyleBackColor = false;
            // 
            // imgQRCode
            // 
            this.imgQRCode.Location = new System.Drawing.Point(20, 360);
            this.imgQRCode.Name = "imgQRCode";
            this.imgQRCode.Size = new System.Drawing.Size(182, 174);
            this.imgQRCode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.imgQRCode.TabIndex = 23;
            this.imgQRCode.TabStop = false;
            // 
            // СashierForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(574, 551);
            this.Controls.Add(this.imgQRCode);
            this.Controls.Add(this.btnCreateQRCode);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAddTicket);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.cbxCategory);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.cbxTime);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.cbxName);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Name = "СashierForm";
            this.Text = "ДОБАВЛЕНИЕ БИЛЕТА";
            ((System.ComponentModel.ISupportInitialize)(this.imgQRCode)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.ComboBox cbxName;
        private System.Windows.Forms.ComboBox cbxTime;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.ComboBox cbxCategory;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Button btnAddTicket;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCreateQRCode;
        private System.Windows.Forms.PictureBox imgQRCode;
    }
}

