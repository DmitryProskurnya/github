﻿using Npgsql;
using ProskurnyaWaterfall.Classes;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ProskurnyaWaterfall.Models
{
    internal class EmployeesFromDb
    {
        public Employee GetEmployee(string login, string password)
        {
            Employee employee = null;
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();
                    string sqlExp = "select id, first_name, last_name, patronymic, role, birth_date, home_address, phone_number, email, login, password from employees where login = @login";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("login", login);
                    NpgsqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        if (password != "")
                        {
                            if (Verification.VerifySHA512Hash(password, (string)reader["password"]))
                            {
                                employee = new Employee((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), (int)reader[4], Convert.ToDateTime(reader[5]),
                                    reader[6].ToString(), reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString());
                            }
                        }
                        else MessageBox.Show("ОШИБКА: Неверный пароль!");
                    }
                    else  MessageBox.Show("ОШИБКА: Нет такого пользователя!");
                    return employee;
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return employee;
            }
        }
    }
}