﻿using laba10._1.Model;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba10._1.Classes
{
    internal class ProductsFromDB
    {
        public List<Products> AllProducts()
        {
            List<Products> products = new List<Products>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "SELECT pr, produkt FROM public.produkty;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        products.Add(new Products((int)reader[0], reader[1].ToString()));
                    }
                }
                reader.Close();
                return products;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return products;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}