﻿namespace laba10._1.Classes
{
   public class Recepty
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Recepty(int id, string name)
        {
            Id = id;
            Name = name;
        }
    }
}