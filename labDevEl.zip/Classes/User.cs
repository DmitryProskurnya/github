﻿using System;
namespace laba10._1.Classes
{
    public class User
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Patronymic { get; set; }
        public DateTime DateOfBirthday { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public int RoleId { get; set; }
        public string Email { get; set; }
        public string PassportSeries { get; set; }
        public string PassportID { get; set; }
        public string IssuedBy { get; set; }
        public DateTime DateOfIssue { get; set; }
        public User(int userId, string firstName, string lastName, string patronymic, DateTime dateOfBirthday, string login, string password, string phone,
            string address, int roleId, string email, string passportSeries, string passportID, string issuedBy, DateTime dateOfIssue)
        {
            UserId = userId;
            FirstName = firstName;
            LastName = lastName;
            Patronymic = patronymic;
            DateOfBirthday = dateOfBirthday;
            Login = login;
            Password = password;
            Phone = phone;
            Address = address;
            RoleId = roleId;
            Email = email;
            PassportSeries = passportSeries;
            PassportID = passportID;
            IssuedBy = issuedBy;
            DateOfIssue = dateOfIssue;
        }
    }
}