﻿using laba10._1.Classes;
using laba10._1.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
namespace laba10._1.Forms
{
    public partial class AddBludo : Form
    {
        string picFileName = "picture.jpg";
        ProductsFromDB productsFromDB = new ProductsFromDB();
        BludaFromBD bludaFromBD = new BludaFromBD();
        public AddBludo()
        {
            InitializeComponent();
            pbBludo.SizeMode = PictureBoxSizeMode.StretchImage;
            pbBludo.Image = Image.FromFile(@"..\..\Images\picture.jpg");
        }
        private void AddBludo_Load(object sender, EventArgs e)
        {
            cmbCategoriya_Load();
            cmbProduct_Load();
        }
        private void cmbCategoriya_Load()
        {
            cmbCategoriya.DataSource = MainForm.categories;
            cmbCategoriya.DisplayMember = "CategoryName";
            cmbCategoriya.ValueMember = "Id";
        }
        private void cmbProduct_Load()
        {
            cmbProduct.DataSource = productsFromDB.AllProducts();
            cmbProduct.DisplayMember = "ProductName";
            cmbProduct.ValueMember = "Id";
        }
        private void btnChoosePic_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if(openFileDialog.ShowDialog() == DialogResult.OK)
            {
                FileInfo fileInfo = new FileInfo(openFileDialog.FileName);
                picFileName = Path.GetFileName(openFileDialog.FileName);
                string distinPath = @"..\..\Images\picture.jpg" + picFileName;
                if (!File.Exists(distinPath))
                {
                    fileInfo.CopyTo(distinPath);
                }
                pbBludo.Image = Image.FromFile(distinPath);
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!DublicateRows(cmbProduct.Text))
            {
                dgvSostavBluda.Rows.Add(cmbProduct.Text, textBox4.Text);
            }
        }
        private bool DublicateRows(string selectProduct)
        {
            bool isDublicate = false;
            for (int i = 0; i < dgvSostavBluda.RowCount; i++)
            {
                if (dgvSostavBluda.Rows[i].Cells[0].Value.ToString() == selectProduct)
                {
                    isDublicate = true;
                    MessageBox.Show("Такой продукт уже есть в списке!");
                    break;
                }
            }
            return isDublicate;
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvSostavBluda.SelectedRows != null)
            {
                dgvSostavBluda.Rows.RemoveAt(dgvSostavBluda.CurrentRow.Index);
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            string picPath = @"..\..\Images\" + picFileName;
            Bludo newBludo = new Bludo(0, tbNameOfBludo.Text, cmbCategoriya.Text, tbOsnova.Text, Convert.ToInt32(tbWeightProd.Text), picPath);
            List<SostavBluda> sostavBl = new List<SostavBluda>();
            for (int i = 0; i < dgvSostavBluda.RowCount; i++)
            {
                sostavBl.Add(new SostavBluda(0, dgvSostavBluda.Rows[i].Cells[0].Value.ToString(), Convert.ToInt32(dgvSostavBluda.Rows[i].Cells[1].Value)));
            }
            bludaFromBD.AddNewBludo(newBludo, sostavBl, cmbCategoriya.SelectedValue.ToString(), picPath);
        }
    }
}