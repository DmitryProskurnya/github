﻿using laba10._1.Model;
using System;
using System.Windows.Forms;
namespace laba10._1.Forms
{
    public partial class AddReceptForm : Form
    {
        ReceptyFromDB receptyFromDB = new ReceptyFromDB();
        public AddReceptForm()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!(tbRecept.Text != ""))
            {
                MessageBox.Show("Введите данные");
                return;
            }
            else
            {
                receptyFromDB.AddRecepts(ReceptForm.currentRecept);
            }
        }
    }
}