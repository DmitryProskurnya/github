﻿using laba10._1.Classes;
using laba10._1.Model;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
namespace laba10._1.Forms
{
    public partial class EditReceptForm : Form
    {
        ReceptyFromDB receptyFromDB = new ReceptyFromDB();
        public EditReceptForm()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!(tbRecept.Text != ""))
            {
                MessageBox.Show("Введите данные");
                return;
            }
            else
            {
                receptyFromDB.EditRecepts(ReceptForm.currentRecept);
            }
        }
        private void EditReceptForm_Load(object sender, EventArgs e)
        {
            List<Recepty> recepties = receptyFromDB.LoadRecepts();
            PrintRecepty(recepties);
        }
        void PrintRecepty(List<Recepty> recepty)
        {
            foreach (Recepty recepty1 in recepty)
            {
                tbRecept.Text = recepty1.Name;
            }
        }
    }
}