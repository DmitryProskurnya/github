﻿namespace laba10._1.Forms
{
    partial class PasswordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxOldPsw = new System.Windows.Forms.TextBox();
            this.textBoxNewPsw = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPswP = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonReg = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Старый пароль";
            // 
            // textBoxOldPsw
            // 
            this.textBoxOldPsw.Location = new System.Drawing.Point(120, 10);
            this.textBoxOldPsw.Name = "textBoxOldPsw";
            this.textBoxOldPsw.Size = new System.Drawing.Size(150, 20);
            this.textBoxOldPsw.TabIndex = 9;
            // 
            // textBoxNewPsw
            // 
            this.textBoxNewPsw.Location = new System.Drawing.Point(120, 40);
            this.textBoxNewPsw.Name = "textBoxNewPsw";
            this.textBoxNewPsw.Size = new System.Drawing.Size(150, 20);
            this.textBoxNewPsw.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Новый пароль";
            // 
            // textBoxPswP
            // 
            this.textBoxPswP.Location = new System.Drawing.Point(120, 70);
            this.textBoxPswP.Name = "textBoxPswP";
            this.textBoxPswP.Size = new System.Drawing.Size(150, 20);
            this.textBoxPswP.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Потдтверждение";
            // 
            // buttonReg
            // 
            this.buttonReg.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonReg.Location = new System.Drawing.Point(70, 100);
            this.buttonReg.Name = "buttonReg";
            this.buttonReg.Size = new System.Drawing.Size(130, 23);
            this.buttonReg.TabIndex = 20;
            this.buttonReg.Text = "Сохранить";
            this.buttonReg.UseVisualStyleBackColor = true;
            this.buttonReg.Click += new System.EventHandler(this.buttonReg_Click);
            // 
            // PasswordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(274, 131);
            this.Controls.Add(this.buttonReg);
            this.Controls.Add(this.textBoxPswP);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxNewPsw);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxOldPsw);
            this.Controls.Add(this.label1);
            this.Name = "PasswordForm";
            this.Text = "Смена пароля";
            this.Load += new System.EventHandler(this.PasswordForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxOldPsw;
        private System.Windows.Forms.TextBox textBoxNewPsw;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPswP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonReg;
    }
}