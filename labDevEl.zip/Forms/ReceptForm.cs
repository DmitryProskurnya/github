﻿using laba10._1.Model;
using laba10._1.Classes;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
namespace laba10._1.Forms
{
    public partial class ReceptForm : Form
    {
        ReceptyFromDB receptyFromDB = new ReceptyFromDB();
        public static Recepty currentRecept { get; set; } = null;
        BludaFromBD bludaFromDB = new BludaFromBD();
        public List<Bludo> bludos = new List<Bludo>();
        int selectedIndex = 0;
        public ReceptForm()
        {
            InitializeComponent();
        }
        private void ReceptForm_Load(object sender, EventArgs e)
        {
            bludos = bludaFromDB.LoadBludos();
            List<SostavBluda> sostavBlud = bludaFromDB.SostavBludaFromDB(bludos[selectedIndex].Id);
            List<Recepty> recepties = receptyFromDB.LoadReceptsById(bludos[selectedIndex].Id);
            PrintSostavBluda(sostavBlud, bludos[selectedIndex].BludoName);
            PrintRecepty(recepties);
        }
        void PrintSostavBluda(List<SostavBluda> sostavBludas, string bludoName)
        {
            ClearSostavBluda();
            lblBludoName.Text = bludoName;
            foreach (SostavBluda sostavBl in sostavBludas)
            {
                listBoxSostavBl.Items.Add(sostavBl.ProductName + ", " + sostavBl.Weight);
            }
        }
        void ClearSostavBluda()
        {
            listBoxSostavBl.Items.Clear();
            lblBludoName.Text = "";
        }
        void PrintRecepty(List<Recepty> recepty)
        {
            ClearRecepty();
            foreach (Recepty recepty1 in recepty)
            {
                tbRecept.Text = recepty1.Name;
            }
        }
        void ClearRecepty()
        {
            tbRecept.Text = "";
        }
        private void button4_Click(object sender, EventArgs e)
        {
            selectedIndex--;
            List<SostavBluda> sostavBlud = bludaFromDB.SostavBludaFromDB(bludos[selectedIndex].Id);
            List<Recepty> recepties = receptyFromDB.LoadReceptsById(bludos[selectedIndex].Id);
            PrintSostavBluda(sostavBlud, bludos[selectedIndex].BludoName);
            PrintRecepty(recepties);
            if(selectedIndex == 0)
            {
                btnPrevious.Enabled = false;
            }
            else
            {
                btnPrevious.Enabled = true;
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            selectedIndex++;
            List<SostavBluda> sostavBlud = bludaFromDB.SostavBludaFromDB(bludos[selectedIndex].Id);
            List<Recepty> recepties = receptyFromDB.LoadReceptsById(bludos[selectedIndex].Id);
            PrintSostavBluda(sostavBlud, bludos[selectedIndex].BludoName);
            PrintRecepty(recepties);
            if (selectedIndex == 32)
            {
                btnNext.Enabled = false;
            }
            else
            {
                btnNext.Enabled = true;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            AddReceptForm addReceptForm = new AddReceptForm();
            if(tbRecept.Text == "")
            {
                addReceptForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("У данного блюда уже есть рецепт!");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            EditReceptForm editReceptForm = new EditReceptForm();
            if (tbRecept.Text == "")
            {
                MessageBox.Show("У данного блюда нет рецепта!");
            }
            else
            {
                editReceptForm.ShowDialog();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            receptyFromDB.RemoveRecepts(selectedIndex);
        }
    }
}