﻿using System;
using laba10._1.Model;
using System.Windows.Forms;
namespace laba10._1.Forms
{
    public partial class RegistrationForm : Form
    {
        UserFromDb userFromDb = new UserFromDb();
        public RegistrationForm()
        {
            InitializeComponent();
        }
        private void buttonReg_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text == "" || textBoxFam.Text == "" || textBoxlogin.Text == "" || textBoxPwd.Text == "" || textBoxPwdP.Text == "")
            {
                MessageBox.Show("Необходимо заполнить все поля!");
                return;
            }
            bool rez = userFromDb.CheckPassword(textBoxPwd.Text, textBoxPwdP.Text);
            if (!rez)
            {
                return;
            }
            else
            {
                if (userFromDb.CheckUser(textBoxlogin.Text))
                {
                    userFromDb.UserAdd(textBoxlogin.Text, textBoxPwd.Text, textBoxName.Text, textBoxFam.Text);
                }
                else
                {
                    return;
                }
            }
        }
    }
}