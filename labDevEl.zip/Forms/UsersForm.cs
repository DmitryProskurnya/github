﻿using laba10._1.Model;
using laba10._1.Classes;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
namespace laba10._1.Forms
{
    public partial class UsersForm : Form
    {
        public List<User> users = new List<User>();
        UserFromDb userFromDb = new UserFromDb();
        User selecteduser = null;
        public UsersForm()
        {
            InitializeComponent();
            dataGridView1.Columns[0].DataPropertyName = "FirstName";
            dataGridView1.Columns[1].DataPropertyName = "Patronymic";
            dataGridView1.Columns[2].DataPropertyName = "LastName";
            dataGridView1.Columns[3].DataPropertyName = "RoleId";
            dataGridView1.Columns[4].DataPropertyName = "UserId";
            dataGridView1.Columns[5].DataPropertyName = "DateOfBirthday";
            dataGridView1.Columns[6].DataPropertyName = "Login";
            dataGridView1.Columns[7].DataPropertyName = "Password";
            dataGridView1.Columns[8].DataPropertyName = "Phone";
            dataGridView1.Columns[9].DataPropertyName = "Address";
            dataGridView1.Columns[4].Visible = false;
            dataGridView1.Columns[5].Visible = false;
            dataGridView1.Columns[6].Visible = false;
            dataGridView1.Columns[7].Visible = false;
            dataGridView1.Columns[8].Visible = false;
            dataGridView1.Columns[9].Visible = false;
        }
        private void ViewAllUsers()
        {
            users = userFromDb.LoadUsers();
            dataGridView1.DataSource = users;
        }
        private void UsersForm_Load(object sender, EventArgs e)
        {
            ViewAllUsers();
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            dateTimePicker1.Enabled = false;
            textBox5.Enabled = false;
            textBox4.Enabled = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            RegistrationForm registrationForm = new RegistrationForm();
            registrationForm.ShowDialog();
            ViewAllUsers();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            int id = (int)dataGridView1[0, i].Value;
            if (dataGridView1.SelectedRows.Count > 0)
            {
                userFromDb.UserRemove(id);
                ViewAllUsers();
            }
            else
            {
                MessageBox.Show("Строка не указана!");
            }
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            selecteduser = users[k];
            textBox1.Text = selecteduser.FirstName;
            textBox2.Text = selecteduser.Patronymic;
            textBox3.Text = selecteduser.LastName;
            dateTimePicker1.Value = selecteduser.DateOfBirthday;
            textBox4.Text = selecteduser.Phone;
            textBox5.Text = selecteduser.Address;
            int i = selecteduser.RoleId - 1;
            comboBox1.SelectedIndex = i;
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (true)
            {
                button3.Enabled = true;
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            int id = (int)dataGridView1[0, i].Value;
            int role = (int)comboBox1.SelectedIndex + 1;
            userFromDb.UserUpdateRole(role, id);
            ViewAllUsers();
        }
    }
}