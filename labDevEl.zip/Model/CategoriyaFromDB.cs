﻿using laba10._1.Classes;
using Npgsql;
using System.Collections.Generic;
using System.Windows.Forms;
namespace laba10._1.Model
{
    class CategoriyaFromDB
    {
        public List<Categoriya> LoadCategories()
        {
            List<Categoriya> categories = new List<Categoriya>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "SELECT v, vid from vidy_blyud";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        categories.Add(new Categoriya(reader[0].ToString(), reader[1].ToString()));
                    }
                    reader.Close();
                }
                return categories;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return categories;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}