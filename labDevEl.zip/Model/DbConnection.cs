﻿namespace laba10._1.Model
{
    internal class DbConnect
    {
        internal static string connectionStr = @"Server=172.20.105.123; Port=5432 ; DataBase=KulinariyaProskurnyaDmitry; User Id=9po11-21-18; Password=zee9aeNg";
    }
}