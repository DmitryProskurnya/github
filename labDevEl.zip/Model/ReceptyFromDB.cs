﻿using laba10._1.Classes;
using Npgsql;
using System.Collections.Generic;
using System.Windows.Forms;
namespace laba10._1.Model
{
    internal class ReceptyFromDB
    {
        public List<Recepty> LoadRecepts()
        {
            List<Recepty> recepts = new List<Recepty>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "SELECT bl, recept FROM public.recepty ORDER BY bl;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        recepts.Add(new Recepty((int)reader[0], reader[1].ToString()));
                    }
                }
                reader.Close();
                return recepts;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return recepts;
            }
            finally
            {
                connection.Close();
            }
        }
        public List<Recepty> LoadReceptsById(int Id)
        {
            List<Recepty> recepts = new List<Recepty>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "SELECT bl, recept FROM public.recepty WHERE bl = @Id ORDER BY bl;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                command.Parameters.AddWithValue("Id", Id);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        recepts.Add(new Recepty((int)reader[0], reader[1].ToString()));
                    }
                }
                reader.Close();
                return recepts;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return recepts;
            }
            finally
            {
                connection.Close();
            }
        }
        public void AddRecepts(Recepty recepty)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "INSERT INTO public.recepty (recept) VALUES (@Name) WHERE bl = @Id;";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("Name", recepty.Name);
                cmd1.Parameters.AddWithValue("Id", recepty.Id);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Рецепт добавлен!");
                }
                else
                {
                    MessageBox.Show("Ошибка записи!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        public void EditRecepts(Recepty recepty)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "UPDATE public.recepty SET recept = @Name WHERE bl = @Id;";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("Name", recepty.Name);
                cmd1.Parameters.AddWithValue("Id", recepty.Id);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Рецепт изменён!");
                }
                else
                {
                    MessageBox.Show("Ошибка записи!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        public void RemoveRecepts(int id)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "DELETE FROM public.recepty WHERE bl = @Id";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("Id", id);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Рецепт удалён!");
                }
                else
                {
                    MessageBox.Show("Ошибка записи!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
    }
}