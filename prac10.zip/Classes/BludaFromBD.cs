﻿using laba10._1.Model;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace laba10._1.Classes
{
    internal class BludaFromBD
    {
        public List<Bludo> LoadBludos()
        {
            List<Bludo> bludos = new List<Bludo>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "SELECT bl, blyudo, public.blyuda.v, osnova, vykhod, bludo_image "
                    + " FROM public.blyuda, public.vidy_blyud WHERE public.vidy_blyud.v = public.blyuda.v ORDER BY bl;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        bludos.Add(new Bludo((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), (int)reader[4], reader[5].ToString()));
                    }
                }
                reader.Close();
                return bludos;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return bludos;
            }
            finally
            {
                connection.Close();
            }
        }
        public List<Bludo> FiltrBludosByCategory(string Id)
        {
            List<Bludo> bludos = new List<Bludo>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "SELECT bl, blyudo, public.blyuda.v, osnova, vykhod, bludo_image"
                    + " FROM public.blyuda, public.vidy_blyud WHERE public.vidy_blyud.v = @Id AND public.vidy_blyud.v = public.blyuda.v ORDER BY bl;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                command.Parameters.AddWithValue("@Id", Id);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        bludos.Add(new Bludo((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), (int)reader[4], reader[5].ToString()));
                    }
                }
                reader.Close();
                return bludos;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return bludos;
            }
            finally
            {
                connection.Close();
            }
        }
        public void SortBludo(string Categoriya)
        {
            Bludo bludos = null;
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "SELECT bl, blyudo, public.blyuda.v, osnova, vykhod, bludo_image "
                    + " FROM public.blyuda, public.vidy_blyud WHERE public.vidy_blyud.v = public.blyuda.v ORDER BY bl AND public.blyuda.v = @Categoriya;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connect);
                command.Parameters.AddWithValue("@Categoriya", Categoriya);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        bludos = new Bludo((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), (int)reader[4], reader[5].ToString());
                    }
                }
                reader.Close();
                return;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                connect.Close();
            }
        }
        public void BludoRemove(int id)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "DELETE FROM public.blyuda WHERE public.blyuda.bl = @Id;";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("Id", id);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Блюдо удалено!");
                }
                else
                {
                    MessageBox.Show("Ошибка записи!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        public List<SostavBluda> SostavBludaFromDB(int idBluda)
        {
            List<SostavBluda> sostavBlud = new List<SostavBluda>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "SELECT produkt, ves " + "FROM public.sostav, public.produkty " +
                    "WHERE public.sostav.pr = public.produkty.pr AND sostav.bl = @idBluda;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                command.Parameters.AddWithValue("@idBluda", idBluda);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        sostavBlud.Add(new SostavBluda(idBluda, reader[0].ToString(), (int)reader[1]));
                    }
                }
                reader.Close();
                return sostavBlud;
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
                return sostavBlud;
            }
            finally { connection.Close(); }
        }
        public void AddNewBludo(Bludo newBludo, List<SostavBluda> sostavBludas, int idCategoriya, string picPatch)
        {
            NpgsqlConnection connection = new NpgsqlConnection(DbConnect.connectionStr);
            connection.Open();
            NpgsqlTransaction transaction = connection.BeginTransaction();
            NpgsqlCommand cmd = connection.CreateCommand();
            cmd.Transaction = transaction;
            try
            {
                cmd.CommandText = "INSERT INTO public.blyuda (blyudo, v, osnova, vykhod, bludo_image) VALUES " +
                    $"(@bludoName, @idCat, @osnova, @vyhod, @picPath);";
                cmd.Parameters.AddWithValue("@bludoName", newBludo.BludoName);
                cmd.Parameters.AddWithValue("@idCat", idCategoriya);
                cmd.Parameters.AddWithValue("@osnova", newBludo.Osnova);
                cmd.Parameters.AddWithValue("@vyhod", newBludo.Vyhod);
                cmd.Parameters.AddWithValue("@picPath", picPatch);
                cmd.ExecuteNonQuery();
                cmd.CommandText = "SELECT MAX(bl) FROM public.blyuda;";
                int idBluda = Convert.ToInt32(cmd.ExecuteScalar());
                MessageBox.Show(idBluda.ToString());
                for(int i = 0; i < sostavBludas.Count; i++)
                {
                    cmd.CommandText = $"INSERT INTO public.sostav (bl, pr, ves) " +
                        $"VALUES ({idBluda},(SELECT public.produkty.pr FROM public.produkty WHERE produkt = '{sostavBludas[i].ProductName}'),"
                        + $"{sostavBludas[i].Weight});";
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show($"Блюдо добавлено!");
                transaction.Commit();
            }
            catch(NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                transaction.Rollback();
            }
        }
    }
}