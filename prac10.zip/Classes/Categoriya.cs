﻿namespace laba10._1.Classes
{
    public class Categoriya
    {
        public string Id { get; set; }
        public string CategoryName { get; set; }
        public Categoriya(string id, string categoryName)
        {
            Id = id;
            CategoryName = categoryName;
        }
    }
}