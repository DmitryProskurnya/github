﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba10._1.Classes
{
    public class Products
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public int Belki { get; set; }
        public int Zhiry { get; set; }
        public int Uglev { get; set; }
        public Products(int id, string productName, int belki, int zhiry, int uglev)
        {
            Id = id;
            ProductName = productName;
            Belki = belki;
            Zhiry = zhiry;
            Uglev = uglev;
        }
    }
}
