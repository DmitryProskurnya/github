﻿using laba10._1.Model;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba10._1.Classes
{
    internal class ProductsFromDB
    {
        public List<Products> AllProducts()
        {
            List<Products> products = new List<Products>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "SELECT pr, produkt, belki, zhiry, uglev "
                    + " FROM public.produkty WHERE ORDER BY pr;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        products.Add(new Products((int)reader[0], reader[1].ToString(), (int)reader[2], (int)reader[3], (int)reader[4]));
                    }
                }
                reader.Close();
                return products;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return products;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}