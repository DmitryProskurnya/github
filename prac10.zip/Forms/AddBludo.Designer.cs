﻿namespace laba10._1.Forms
{
    partial class AddBludo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbNameOfBludo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbCategoriya = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbOsnova = new System.Windows.Forms.TextBox();
            this.tbWeightProd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pbBludo = new System.Windows.Forms.PictureBox();
            this.btnChoosePic = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbProduct = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dgvSostavBluda = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbBludo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSostavBluda)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Название блюда";
            // 
            // tbNameOfBludo
            // 
            this.tbNameOfBludo.Location = new System.Drawing.Point(110, 10);
            this.tbNameOfBludo.Name = "tbNameOfBludo";
            this.tbNameOfBludo.Size = new System.Drawing.Size(200, 20);
            this.tbNameOfBludo.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Категория";
            // 
            // cmbCategoriya
            // 
            this.cmbCategoriya.FormattingEnabled = true;
            this.cmbCategoriya.Location = new System.Drawing.Point(110, 40);
            this.cmbCategoriya.Name = "cmbCategoriya";
            this.cmbCategoriya.Size = new System.Drawing.Size(100, 21);
            this.cmbCategoriya.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Основа";
            // 
            // tbOsnova
            // 
            this.tbOsnova.Location = new System.Drawing.Point(110, 70);
            this.tbOsnova.Name = "tbOsnova";
            this.tbOsnova.Size = new System.Drawing.Size(100, 20);
            this.tbOsnova.TabIndex = 5;
            // 
            // tbWeightProd
            // 
            this.tbWeightProd.Location = new System.Drawing.Point(110, 100);
            this.tbWeightProd.Name = "tbWeightProd";
            this.tbWeightProd.Size = new System.Drawing.Size(100, 20);
            this.tbWeightProd.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Вес";
            // 
            // pbBludo
            // 
            this.pbBludo.Location = new System.Drawing.Point(320, 10);
            this.pbBludo.Name = "pbBludo";
            this.pbBludo.Size = new System.Drawing.Size(150, 110);
            this.pbBludo.TabIndex = 8;
            this.pbBludo.TabStop = false;
            // 
            // btnChoosePic
            // 
            this.btnChoosePic.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnChoosePic.Location = new System.Drawing.Point(480, 10);
            this.btnChoosePic.Name = "btnChoosePic";
            this.btnChoosePic.Size = new System.Drawing.Size(100, 23);
            this.btnChoosePic.TabIndex = 9;
            this.btnChoosePic.Text = "Выбрать";
            this.btnChoosePic.UseVisualStyleBackColor = true;
            this.btnChoosePic.Click += new System.EventHandler(this.btnChoosePic_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(210, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Добавить состав блюда";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Продукт";
            // 
            // cmbProduct
            // 
            this.cmbProduct.FormattingEnabled = true;
            this.cmbProduct.Location = new System.Drawing.Point(110, 150);
            this.cmbProduct.Name = "cmbProduct";
            this.cmbProduct.Size = new System.Drawing.Size(100, 21);
            this.cmbProduct.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(280, 155);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Вес";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(320, 150);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 14;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(280, 180);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 23);
            this.btnAdd.TabIndex = 15;
            this.btnAdd.Text = "Добавить";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dgvSostavBluda
            // 
            this.dgvSostavBluda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSostavBluda.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dgvSostavBluda.Location = new System.Drawing.Point(10, 180);
            this.dgvSostavBluda.Name = "dgvSostavBluda";
            this.dgvSostavBluda.Size = new System.Drawing.Size(250, 150);
            this.dgvSostavBluda.TabIndex = 16;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Продукт";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Вес";
            this.Column2.Name = "Column2";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(280, 210);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 23);
            this.btnDelete.TabIndex = 17;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(470, 310);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 23);
            this.btnSave.TabIndex = 18;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // AddBludo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 341);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.dgvSostavBluda);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbProduct);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnChoosePic);
            this.Controls.Add(this.pbBludo);
            this.Controls.Add(this.tbWeightProd);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbOsnova);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbCategoriya);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbNameOfBludo);
            this.Controls.Add(this.label1);
            this.Name = "AddBludo";
            this.Text = "Добавление блюда";
            this.Load += new System.EventHandler(this.AddBludo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbBludo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSostavBluda)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbNameOfBludo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbCategoriya;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbOsnova;
        private System.Windows.Forms.TextBox tbWeightProd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pbBludo;
        private System.Windows.Forms.Button btnChoosePic;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbProduct;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dgvSostavBluda;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
    }
}