﻿using laba10._1.Model;
using laba10._1.Classes;
using System;
using System.Windows.Forms;
namespace laba10._1.Forms
{
    public partial class AuthorizationForm : Form
    {
        UserFromDb userFromDb = new UserFromDb();
        public static User currentUser { get; set; } = null;
        public AuthorizationForm()
        {
            InitializeComponent();
        }
        private void btnAvtoriz_Click(object sender, EventArgs e)
        {
            if(!(textBoxLogin.Text != "" && textBoxPsw.Text != ""))
            {
                MessageBox.Show("Введите данные");
                return;
            }
            else
            {
                currentUser = userFromDb.GetUser(textBoxLogin.Text, textBoxPsw.Text);
                if(currentUser != null)
                {
                    MainForm mainForm = new MainForm();
                    mainForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Нет такого пользователя");
                    return;
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            RegistrationForm registrationForm = new RegistrationForm();
            registrationForm.ShowDialog();
            this.Hide();
        }
    }
}