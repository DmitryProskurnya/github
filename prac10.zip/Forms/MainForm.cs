﻿using laba10._1.Classes;
using laba10._1.Model;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
namespace laba10._1.Forms
{
    public partial class MainForm : Form
    {
        public List<Bludo> bludos = new List<Bludo>();
        BludaFromBD bludaFromDB = new BludaFromBD();
        public static List<Categoriya> categories = new List<Categoriya>();
        CategoriyaFromDB categoriyaFromDB = new CategoriyaFromDB();
        public MainForm()
        {
            InitializeComponent();
            dataGridView1.Columns[0].DataPropertyName = "Id";
            dataGridView1.Columns[1].DataPropertyName = "Image";
            dataGridView1.Columns[2].DataPropertyName = "BludoName";
            dataGridView1.Columns[3].DataPropertyName = "Categoriya";
            dataGridView1.Columns[4].DataPropertyName = "Osnova";
            dataGridView1.Columns[5].DataPropertyName = "Vyhod";
            dataGridView1.Columns[0].Visible = false;
        }
        private void ViewAllBludos()
        {
            bludos = bludaFromDB.LoadBludos();
            dataGridView1.DataSource = bludos;
        }
        private void MainForm_Load(object sender, EventArgs e)
        {
            ViewAllBludos();
            UsersToolStripMenuItem.Visible = false;
            categories = categoriyaFromDB.LoadCategories();
            categories.Insert(0, new Categoriya("Все", "All"));
            cnbCategoriya.DataSource = categories;
            cnbCategoriya.DisplayMember = "CategoryName";
            cnbCategoriya.ValueMember = "Id";
            switch (AuthorizationForm.currentUser.RoleId)
            {
                case 1:
                    UsersToolStripMenuItem.Visible = true;
                    break;
                case 2:
                    toolStripMenuItemAdd.Visible = false;
                    toolStripMenuItemDel.Visible = false;
                    break;
                case 3:
                    продуктToolStripMenuItem1.Visible = false;
                    break;
            }
            toolStripMenuItemProf.Text = AuthorizationForm.currentUser.FirstName + " " + AuthorizationForm.currentUser.LastName;
            cnbCategoriya.SelectedIndex = 0;
        }
        private void ToolStripMenuItem5_Click(object sender, EventArgs e)
        {
            ProfilForm profilForm = new ProfilForm();
            DialogResult result = profilForm.ShowDialog();
            if (result == DialogResult.OK)
            {
                toolStripMenuItemProf.Text = AuthorizationForm.currentUser.FirstName + " " + AuthorizationForm.currentUser.LastName;
            }
        }
        private void сменитьПарольToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PasswordForm passwordForm = new PasswordForm();
            passwordForm.Show();
        }
        private void сменитьПользователяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AuthorizationForm authorizationForm = new AuthorizationForm();
            authorizationForm.ShowDialog(this);
        }
        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void UsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UsersForm usersForm = new UsersForm();
            usersForm.Show();
        }
        private void просмортБлюдToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            BludoForm bludoForm = new BludoForm();
            bludoForm.Show();
        }
        private void toolStripMenuItemAdd_Click(object sender, EventArgs e)
        {
            AddBludo addBludo = new AddBludo();
            addBludo.Show();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ClearSostavBluda();
            dataGridView1.DataSource = SearchBludos(textBox1.Text);
        }
        private List<Bludo> SearchBludos(string txbSearch)
        {
            List<Bludo> bludoSearch = new List<Bludo>();
            foreach (Bludo item in bludos)
            {
                if (item.BludoName.StartsWith(txbSearch) || item.Osnova.StartsWith(txbSearch))
                {
                    bludoSearch.Add(item);
                }
            }
            return bludoSearch;
        }
        private void cnbCategoriya_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearSostavBluda();
            if (cnbCategoriya.SelectedIndex == 0)
            {
                ViewAllBludos();
            }
            else
            {
                bludos = bludaFromDB.FiltrBludosByCategory(Convert.ToString(cnbCategoriya.SelectedValue));
                dataGridView1.DataSource = bludos;
            }
        }
        private void toolStripMenuItemDel_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            int id = (int)dataGridView1[0, i].Value;
            if (dataGridView1.SelectedRows.Count > 0)
            {
                bludaFromDB.BludoRemove(id);
                ViewAllBludos();
            }
            else
            {
                MessageBox.Show("Строка не указана!");
            }
        }
        void PrintSostavBluda(List<SostavBluda> sostavBludas, string bludoName)
        {
            ClearSostavBluda();
            lblNameOfBludo.Text = bludoName;
            foreach(SostavBluda sostavBl in sostavBludas)
            {
                listBoxSostavBluda.Items.Add(sostavBl.ProductName + ", " + sostavBl.Weight);
            }
        }
        void ClearSostavBluda()
        {
            listBoxSostavBluda.Items.Clear();
            lblNameOfBludo.Text = "";
        }
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRowIndex = dataGridView1.CurrentRow.Index;
            List<SostavBluda> sostavBlud = bludaFromDB.SostavBludaFromDB(bludos[selectedRowIndex].Id);
            PrintSostavBluda(sostavBlud, bludos[selectedRowIndex].BludoName);
        }
    }
}