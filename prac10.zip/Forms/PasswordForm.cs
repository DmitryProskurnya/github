﻿using laba10._1.Classes;
using laba10._1.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace laba10._1.Forms
{
    public partial class PasswordForm : Form
    {
        UserFromDb userFromDb = new UserFromDb();
        public PasswordForm()
        {
            InitializeComponent();
        }
        private void PasswordForm_Load(object sender, EventArgs e)
        {
        }
        private void buttonReg_Click(object sender, EventArgs e)
        {
            if (AuthorizationForm.currentUser.Password != Verification.GetSHA512Hash(textBoxOldPsw.Text))
            {
                MessageBox.Show("Неверно введён пароль!");
                return;
            }
            if (textBoxNewPsw.Text == "")
            {
                MessageBox.Show("Введите новый пароль!");
                return;
            }
            bool rez = userFromDb.CheckPassword(textBoxNewPsw.Text, textBoxPswP.Text);
            if (!rez)
            {
                return;
            }
            else
            {
                AuthorizationForm.currentUser.Password = textBoxNewPsw.Text;
                userFromDb.UserUpdatePassword(AuthorizationForm.currentUser);
            }
        }
    }
}