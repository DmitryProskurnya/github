﻿using laba10._1.Model;
using System;
using System.Windows.Forms;
namespace laba10._1.Forms
{
    public partial class ProfilForm : Form
    {
        UserFromDb userfromDb = new UserFromDb();
        public ProfilForm()
        {
            InitializeComponent();
        }
        private void ProfilForm_Load(object sender, EventArgs e)
        {
            textBoxName.Text = AuthorizationForm.currentUser.FirstName;
            textBoxFam.Text = AuthorizationForm.currentUser.LastName;
            textBoxOtch.Text = AuthorizationForm.currentUser.Patronymic;
            dtBirthday.Value = AuthorizationForm.currentUser.DateOfBirthday;
            textBoxPhone.Text = AuthorizationForm.currentUser.Phone;
            textBoxAdress.Text = AuthorizationForm.currentUser.Address;
        }
        private void buttonReg_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text != "" && textBoxFam.Text != "")
            {
                AuthorizationForm.currentUser.FirstName = textBoxName.Text;
                AuthorizationForm.currentUser.LastName = textBoxFam.Text;
                AuthorizationForm.currentUser.Patronymic = textBoxOtch.Text;
                AuthorizationForm.currentUser.DateOfBirthday = dtBirthday.Value;
                AuthorizationForm.currentUser.Phone = textBoxPhone.Text;
                AuthorizationForm.currentUser.Address = textBoxAdress.Text;
                userfromDb.UserUpdateProfil(AuthorizationForm.currentUser);
            }
        }
    }
}