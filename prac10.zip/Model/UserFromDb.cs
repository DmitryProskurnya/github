﻿using System;
using System.Windows.Forms;
using laba10._1.Classes;
using System.Collections.Generic;
using Npgsql;
namespace laba10._1.Model
{
    class UserFromDb
    {
        public User GetUser(string login, string password)
        {
            User user = null;
            try
            {
                using(NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr))
                {
                    connect.Open();
                    string sqlExp = "SELECT * FROM Users WHERE login=@login ";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("login", login);
                    NpgsqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        if(password != "")
                        {
                            if(Verification.VerifySHA512Hash(password, (string)reader["Password"]))
                            {
                                DateTime birthday = DateTime.Now;
                                if (!(reader[4] is DBNull))
                                {
                                    birthday = Convert.ToDateTime(reader[4]);
                                }
                                user = new User((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(),
                                    birthday, reader[5].ToString(), reader[6].ToString(), reader[7].ToString(),
                                    reader[8].ToString(), (int)reader[9]);
                            }
                            else
                            {
                                MessageBox.Show("Неверный пароль");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Нет такого пользователя");
                    }
                    return user;
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return user;
            }
        }
        public bool CheckPassword(string password, string passRepeat)
        {
            if (password.Length < 6)
            {
                MessageBox.Show("Длина пароля не может быть меньше 6 символов!");
                return false;
            }
            else
            {
                bool f, f1, f2;
                f = f1 = f2 = false;
                for (int i = 0; i < password.Length; i++)
                {
                    if (Char.IsDigit(password[i]))
                    {
                        f1 = true;
                    }
                    if (Char.IsUpper(password[i]))
                    {
                        f2 = true;
                    }
                    if (f1 && f2)
                    {
                        break;
                    }
                }

                if (!(f1 && f2))
                {
                    MessageBox.Show("Пароль должен содержать хотя бы одну цифру и одну заглавную букву!");
                    return f1 && f2;
                }
                else
                {
                    string simbol = "!@#$%^";
                    for (int i = 0; i < password.Length; i++)
                    {
                        for (int j = 0; j < simbol.Length; j++)
                        {
                            if (password[i] == simbol[j])
                            {
                                f = true;
                                break;
                            }
                        }
                    }
                    if (!f)
                    {
                        MessageBox.Show("Пароль должен содержать один из символов '!@#$%^'!");
                    }
                    if ((password == passRepeat) && f)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Неверно потверждён пароль!");
                        return false;
                    }
                }
            }
        }
        public bool CheckUser(string login)
        {
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr))
                {
                    connect.Open();
                    string sqlExp = "SELECT login FROM Users WHERE login=@login";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("@login", login);
                    NpgsqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        MessageBox.Show("Такой логин уже есть!");
                        return false;
                    }
                    else
                    {
                        reader.Close();
                        return true;
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        public void UserAdd(string login, string password, string firstName, string lastName)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "INSERT INTO public.Users (firstname, lastname, patronymic, login, password, adress, role_id, phone) "
                    + "VALUES (@FirstName, @LastName, ' ', @login, @password, ' ', 3, ' ')";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("login", login);
                cmd1.Parameters.AddWithValue("password", Verification.GetSHA512Hash(password));
                cmd1.Parameters.AddWithValue("FirstName", firstName);
                cmd1.Parameters.AddWithValue("LastName", lastName);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Вы успешно зарегистрированы!");
                }
                else
                {
                    MessageBox.Show("Ошибка записи!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        public void UserUpdateProfil(User user)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "UPDATE public.users SET firstname = @FirstName, lastname = @LastName, patronymic = @Patronymic, " +
                    "dateofbirthday = @DateOfBirthday, adress = @Address, phone = @Phone WHERE user_id = @UserId";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("FirstName", user.FirstName);
                cmd1.Parameters.AddWithValue("LastName", user.LastName);
                cmd1.Parameters.AddWithValue("Patronymic", user.Patronymic);
                cmd1.Parameters.AddWithValue("DateOfBirthday", user.DateOfBirthday);
                cmd1.Parameters.AddWithValue("Address", user.Address);
                cmd1.Parameters.AddWithValue("Phone", user.Phone);
                cmd1.Parameters.AddWithValue("UserId", user.UserId);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Данные обновлены!");
                }
                else
                {
                    MessageBox.Show("Ошибка записи!");
                }
            }
            catch(NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        public void UserUpdatePassword(User user)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "UPDATE public.users SET password = @Password WHERE user_id = @UserId";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("Password", Verification.GetSHA512Hash(user.Password));
                cmd1.Parameters.AddWithValue("UserId", user.UserId);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Пароль обновлён!");
                }
                else
                {
                    MessageBox.Show("Ошибка записи!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        public List<User> LoadUsers()
        {
            List<User> users = new List<User>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "SELECT * FROM public.users;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {

                    while (reader.Read())
                    {
                        DateTime birthday = DateTime.Now;
                        if (!(reader[4] is DBNull))
                        {
                            birthday = Convert.ToDateTime(reader[4]);
                        }
                        users.Add(new User((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(),
                                    birthday, reader[5].ToString(), reader[6].ToString(), reader[7].ToString(),
                                    reader[8].ToString(), (int)reader[9]));
                    }
                }
                reader.Close();
                return users;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return users;
            }
            finally
            {
                connection.Close();
            }
        }
        public void UserUpdateRole(int RoleId, int id)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "UPDATE public.users SET role_id = @RoleId WHERE user_id = @UserId";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("RoleId", RoleId);
                cmd1.Parameters.AddWithValue("UserId", id);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Роль обновлена!");
                }
                else
                {
                    MessageBox.Show("Ошибка записи!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
        public void UserRemove(int id)
        {
            NpgsqlConnection connect = new NpgsqlConnection(DbConnect.connectionStr);
            try
            {
                connect.Open();
                string sqlExp = "DELETE FROM public.users WHERE user_id = @UserId";
                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlExp, connect);
                cmd1.Parameters.AddWithValue("UserId", id);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Пользователь удалён!");
                }
                else
                {
                    MessageBox.Show("Ошибка записи!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            connect.Close();
        }
    }
}