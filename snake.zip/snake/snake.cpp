﻿#include <iostream>
#include <conio.h>
using namespace std;
bool gameover;
const int width = 20;
const int height = 20;
int x, y, fruitx, fruity, score;
int death1x[4], death1y[4];
int death2x[4], death2y[4];
int death3x[4], death3y[4];
int tailx[100], taily[100];
int ntail;
enum edirection {STOP = 0, LEFT, RIGHT, UP, DOWN};
edirection dir;
void setup() {
	gameover = false;
	dir = STOP;
	x = width / 2 - 1;
	y = height / 2 - 1;
	fruitx = rand() % width;
	fruity = rand() % height;
	death1x[0] = rand() % width - 1;
	death1y[0] = rand() % height;
	death1x[1] = death1x[0] + 1;
	death1y[1] = death1y[0];
	death1x[2] = death1x[0];
	death1y[2] = death1y[0] + 1;
	death1x[3] = death1x[0] + 1;
	death1y[3] = death1y[0] + 1;
	death2x[0] = rand() % width - 1;
	death2y[0] = rand() % height;
	death2x[1] = death2x[0] + 1;
	death2y[1] = death2y[0];
	death2x[2] = death2x[0];
	death2y[2] = death2y[0] + 1;
	death2x[3] = death2x[0] + 1;
	death2y[3] = death2y[0] + 1;
	death3x[0] = rand() % width - 1;
	death3y[0] = rand() % height;
	death3x[1] = death3x[0] + 1;
	death3y[1] = death3y[0];
	death3x[2] = death3x[0];
	death3y[2] = death3y[0] + 1;
	death3x[3] = death3x[0] + 1;
	death3y[3] = death3y[0] + 1;
	score = 0;
}
void draw() {
	system("cls");
	for (int i = 0; i < width + 1; i++)
		cout << "#";
	cout << endl;
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			if (j == 0 || j == width - 1)
				cout << "#";
			if (i == y && j == x)
				cout << "0";
			else if (i == fruity && j == fruitx)
				cout << "F";
			else if (i == death1y[0] && j == death1x[0]) {
				cout << "X";
			}
			else if (i == death1y[1] && j == death1x[1]) {
				cout << "X";
			}
			else if (i == death1y[2] && j == death1x[2]) {
				cout << "X";
			}
			else if (i == death1y[3] && j == death1x[3]) {
				cout << "X";
			}
			else if (i == death2y[0] && j == death2x[0]) {
				cout << "X";
			}
			else if (i == death2y[1] && j == death2x[1]) {
				cout << "X";
			}
			else if (i == death2y[2] && j == death2x[2]) {
				cout << "X";
			}
			else if (i == death2y[3] && j == death2x[3]) {
				cout << "X";
			}
			else if (i == death3y[0] && j == death3x[0]) {
				cout << "X";
			}
			else if (i == death3y[1] && j == death3x[1]) {
				cout << "X";
			}
			else if (i == death3y[2] && j == death3x[2]) {
				cout << "X";
			}
			else if (i == death3y[3] && j == death3x[3]) {
				cout << "X";
			}
			else {
				bool print = false;
				for (int k = 0; k < ntail; k++) {
					if (tailx[k] == j && taily[k] == i) {
						print = true;
						cout << "o";
					}
				}
				if(!print)
					cout << " ";
			}
		}
		cout << endl;
	}
	for (int i = 0; i < width + 1; i++)
		cout << "#";
	cout << endl;
	cout << "Score: " << score << endl;
}
void input() {
	if (_kbhit()) {
		switch (_getch()) {
		case 'a':
			dir = LEFT;
			break;
		case 'd':
			dir = RIGHT;
			break;
		case 'w':
			dir = UP;
			break;
		case 's':
			dir = DOWN;
			break;
		case 'x':
			gameover = true;
			break;
		}
	}
}
void logic() {
	int prevx = tailx[0];
	int prevy = taily[0];
	int prev2x, prev2y;
	tailx[0] = x;
	taily[0] = y;
	for (int i = 1; i < ntail; i++) {
		prev2x = tailx[i];
		prev2y = taily[i];
		tailx[i] = prevx;
		taily[i] = prevy;
		prevx = prev2x;
		prevy = prev2y;
	}
	switch (dir)
	{
	case LEFT:
		x--;
		break;
	case RIGHT:
		x++;
		break;
	case UP:
		y--;
		break;
	case DOWN:
		y++;
		break;
	}
	if ((x == death1x[0] && y == death1y[0]) || (x == death1x[1] && y == death1y[1]) || (x == death1x[2] && y == death1y[2])
		|| (x == death1x[3] && y == death1y[3])) {
		gameover = true;
	}
	if ((x == death2x[0] && y == death2y[0]) || (x == death2x[1] && y == death2y[1]) || (x == death2x[2] && y == death2y[2])
		|| (x == death2x[3] && y == death2y[3])) {
		gameover = true;
	}
	if ((x == death3x[0] && y == death3y[0]) || (x == death3x[1] && y == death3y[1]) || (x == death3x[2] && y == death3y[2])
		|| (x == death3x[3] && y == death3y[3])) {
		gameover = true;
	}
	if (x >= width - 1)
		x = 0;
	else if (x < 0)
		x = width - 2;
	if (y >= height)
		y = 0;
	else if (y < 0)
		y = height - 1;
	for (int i = 0;i < ntail;i++) {
		if (tailx[i] == x && taily[i] == y)
			gameover = true;
	}
	if (x == fruitx && y == fruity) {
		score += 10;
		fruitx = rand() % width;
		fruity = rand() % height;
		ntail++;
	}
}
int main() {
	setup();
	while (!gameover) {
		draw();
		input();
		logic();
	}
	return 0;
}