﻿namespace ProskurnyaDmitryCooking.Classes
{
    public class Class
    {
        public int Class_number { get; set; }
        public string Specialization { get; set; }
        public int Number_of_students { get; set; }
        public Class(int class_number, string specialization, int number_of_students)
        {
            Class_number = class_number;
            Specialization = specialization;
            Number_of_students = number_of_students;
        }
    }
}