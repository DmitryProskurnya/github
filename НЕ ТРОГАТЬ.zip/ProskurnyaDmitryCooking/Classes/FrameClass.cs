﻿using System.Windows.Controls;
namespace ProskurnyaDmitryCooking.Classes
{
    internal class FrameClass
    {
        public static Frame studentFrame;
        public static Frame classFrame;
        public static Frame teacherFrame;
    }
}