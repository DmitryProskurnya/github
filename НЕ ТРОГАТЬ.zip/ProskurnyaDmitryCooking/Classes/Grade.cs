﻿using System;
namespace ProskurnyaDmitryCooking.Classes
{
    public class Grade
    {
        public int Student_number { get; set; }
        public int Subject_code { get; set; }
        public int Grade_number { get; set; }
        public DateTime Assessment_date { get; set; }
        public string Presence_absence { get; set; }
        public Grade (int student_number, int subject_code, int grade_number, DateTime assessment_date, string presence_absence)
        {
            Student_number = student_number;
            Subject_code = subject_code;
            Grade_number = grade_number;
            Assessment_date = assessment_date;
            Presence_absence = presence_absence;
        }
    }
}