﻿using System;
namespace ProskurnyaDmitryCooking.Classes
{
    public class Student
    {
        public int Student_number { get; set; }
        public int Class_number { get; set; }
        public string Student_name { get; set; }
        public DateTime Student_date_of_birth { get; set; }
        public string Student_home_address { get; set; }
        public string Student_phone_number { get; set; }
        public int Order_number { get; set; }
        public DateTime Order_date { get; set; }
        public Student(int student_number, int class_number, string student_name, DateTime student_date_of_birth, string student_home_address, string student_phone_number, int order_number, DateTime order_date)
        {
            Student_number = student_number;
            Class_number = class_number;
            Student_name = student_name;
            Student_date_of_birth = student_date_of_birth;
            Student_home_address = student_home_address;
            Student_phone_number = student_phone_number;
            Order_number = order_number;
            Order_date = order_date;
        }
    }
}