﻿using Npgsql;
using ProskurnyaDmitryCooking.Classes;
using System.Collections.Generic;
using System.Windows;
namespace ProskurnyaDmitryCooking.Models
{
    internal class ClassFromDb
    {
        public List<Class> LoadClass()
        {
            List<Class> classes = new List<Class>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select class_number, specialization, number_of_students from class order by class_number;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        classes.Add(new Class((int)reader[0], reader[1].ToString(), (int)reader[2]));
                    }
                }
                reader.Close();
                return classes;
            }
            catch (NpgsqlException e)
            {
                MessageBox.Show(e.Message);
                return classes;
            }
            finally { connection.Close(); }
        }
    }
}