﻿namespace ProskurnyaDmitryCooking.Models
{
    internal class DbConnection
    {
        internal static string connectionStr = @"Server=172.20.105.123; Port=5432 ; DataBase=ProskurnyaDmitrySchool; User Id=9po11-21-18; Password=zee9aeNg";
    }
}