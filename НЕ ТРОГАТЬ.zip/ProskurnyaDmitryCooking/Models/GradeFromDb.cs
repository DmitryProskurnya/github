﻿using Npgsql;
using ProskurnyaDmitryCooking.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
namespace ProskurnyaDmitryCooking.Models
{
    internal class GradeFromDb
    {
        public List<Grade> LoadGrade()
        {
            List<Grade> grade = new List<Grade>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select student_number, subject_code, grade, assessment_date, presence_absence from grade order by student_number;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        grade.Add(new Grade((int)reader[0], (int)reader[1], (int)reader[2], Convert.ToDateTime(reader[3]), reader[4].ToString()));
                    }
                }
                reader.Close();
                return grade;
            }
            catch (NpgsqlException e)
            {
                MessageBox.Show(e.Message);
                return grade;
            }
            finally { connection.Close(); }
        }
    }
}