﻿using Npgsql;
using ProskurnyaDmitryCooking.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
namespace ProskurnyaDmitryCooking.Models
{
    internal class StudentFromDb
    {
        public List<Student> LoadStudent()
        {
            List<Student> student = new List<Student>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);
            try
            {
                connection.Open();
                string sqlExp = "select student.student_number, student_name, specialization, grade, subject.subject_name from student"
                    + "join class on student.class_number = class.class_number join grade on grade.student_number = student.student_number join"
                    + "subject on subject.subject_code = grade.subject_code order by student_number;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        student.Add(new Student((int)reader[0], (int)reader[1], reader[2].ToString(), Convert.ToDateTime(reader[3]), reader[4].ToString(), reader[5].ToString(), (int)reader[6], Convert.ToDateTime(reader[7])));
                    }
                }
                reader.Close();
                return student;
            }
            catch (NpgsqlException e)
            {
                MessageBox.Show(e.Message);
                return student;
            }
            finally { connection.Close(); }
        }
    }
}