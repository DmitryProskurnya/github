﻿using ProskurnyaDmitryCooking.Classes;
using ProskurnyaDmitryCooking.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace ProskurnyaDmitryCooking.Pages
{
    /// <summary>
    /// Логика взаимодействия для studentPage.xaml
    /// </summary>
    public partial class StudentPage : Page
    {
        public List<Student> students = new List<Student>();
        StudentFromDb studentFromDb = new StudentFromDb();
        public static List<Class> classes = new List<Class>();
        ClassFromDb classFromDb = new ClassFromDb();
        public StudentPage()
        {
            InitializeComponent();
        }
        private void ViewAllStudents()
        {
            students = studentFromDb.LoadStudent();
            listViewStudents.ItemsSource = students;
        }
        private void listViewStudents_Loaded(object sender, RoutedEventArgs e)
        {
            ViewAllStudents();
            classes = classFromDb.LoadClass();
            classes.Insert(0, new Class(0, "Все", 0));
            cbClass.ItemsSource = classes;
            cbClass.DisplayMemberPath = "Class_number";
        }
    }
}